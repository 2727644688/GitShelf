The MyCountries component is now used without the name attribute. However, this reactive variable is transmitted to child components using the provide("name", name) method and will be retrieved in the MyCountries component through the inject("name") method.

The MyCountries component is modified as follows:

MyCountries component (file src/components/MyCountries.vue)  
<script setup>   
import { ref, onMounted, watch, inject } from "vue";   
const names $=$ ref([]); // Countries names displayed in the list   
let countries $=$ []; // All country names (retrieved only once at startup)  
const name = inject("name"); // The reactive variable name is retrieved

```javascript
onMounted(() => {
    var url = "https://restcountries.com/v3.1/all";
    fetch(url)
    .then((res) => res.text())
    .then((data) => {
    countries = JSON.parse(data).map(function(elem) {
    return elem.name.common;
    });
    // In ascending alphabetical order
    countries = countries.sort((n1, n2) => {
    if (n1 > n2) return 1;
    if (n1 < n2) return -1;
    return 0;
    });
```

```vue
names.value = countries;
})
.catch((err) => names.value = [err.toString()]);
});
watch(name, () => {
    let countriesFiltered = countries.filter((n) => {
    const reg = new RegExp("^" + name.value, "i");
    if (n.match(reg)) return true;
    else return false;
    });
    names.value = countriesFiltered;
});

</script>

<template>

<h3>Country List:</h3>

<div v-show=!countries.length">Fetching countries in progress...</div>

<ul>
<li v-for="n in names" :key="n" <{{n}}</li>
</ul>

</template>
```

The reactive variable name can be directly observed using the watch(name, callback) method, as it is indeed the reactive variable name being observed here, and not an attribute transmitted via props.name as before. Let’s verify that this works:

![](images/ec76ad5888d06c12619b4f13ef30880a5d8864bac40007e99c2b73661ef992e4.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
Country: f
Country List:
• Falkland Islands
• Faroe Islands
• Fiji
• Finland
• France
• French Guiana
• French Polynesia
• French Southern and Antarctic Lands
</details>

Figure 4-11. Usage of provide() and inject()

## Giving Focus to the Input Field

The program can be further enhanced by giving focus to the input field as soon as the page is displayed. The focus() method provided by the DOM API is employed for this purpose.

It is necessary to modify the App component that contains the input field to which focus should be given. The onMounted() method is utilized to access the DOM element corresponding to the input field.

Giving focus to the input field (file src/App.vue)  
```vue
<script setup>

import MyCountries from './components/MyCountries.vue'
import { ref, provide, onMounted } from "vue";
const name = ref("");
provide("name", name);

onMounted(()=>document.querySelector("input[type=text])".focus());
</script>

<template>

<b>Country</b>: <input type="text" v-model="name" />
<br>
<MyCountries />
</template>
```

The input field is accessed through the DOM API, for example, by using document.querySelector(selector). All that remains is to use the focus() method of the DOM API on this element to give it focus.

![](images/56e71f38fbe5c10a33714fc5caf092b1d13f66d7553a14f7dddcbe99780389ea.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
 Country: |
Country List:
• Afghanistan
• Albania
• Algeria
• American Samoa
• Andorra
• Angola
• Anguilla
• Antarctica
• Antigua and Barbuda
• Argentina
• Armenia
• Aruba
• Australia
• Austria
• Azerbaijan
• Bahamas
</details>

Figure 4-12. The input field gains focus directly

In the next chapter, we will explore the creation of a new directive that directly gives focus to the input field, providing a more optimal approach.

## Conclusion

You now have a comprehensive understanding of how to perform HTTP requests in a Vue.js application. You have learned to retrieve data from a remote server and seamlessly integrate it into your application. The example of the country list has allowed you to implement these concepts, providing you with a practical and concrete experience.

While we have explored leveraging data from an external source, the upcoming chapter will take you further into customizing and optimizing Vue.js applications. We will delve into creating new directives and composables, powerful tools that enable you to build advanced features and efficiently reuse your application logic. These techniques will make your code both cleaner and more functional.

# Day 5: Mastering the Creation of Directives in Vue.js

We have covered the main features of Vue.js. Now, let’s explore how these features can be extended by creating new directives. Vue.js provides standard directives such as v-show, v-if, v-for, v-bind, or v-on. It is possible to create custom directives tailored for use in our application components.

## Why Create New Directives?

Creating custom directives offers several advantages that can significantly enhance code quality and maintainability. Some of these benefits include the following:

1. Code Reusability: Encapsulate frequently used behaviors into a directive and reuse them across multiple components.  
2. Clarity and Readability: Using a well-named directive makes the template more readable and expressive.

3. Testability: Directives can be independently tested, facilitating the verification of their correct functionality.  
4. Extensibility: Easily extend existing directive functionalities or create new directives for custom behaviors.

The ability to create custom directives promotes good code organization, reusability, and readability.

Now that we understand the usefulness of writing custom directives, let’s delve into how to organize the code that will be executed when the directive is used.

## Directive Lifecycle

A Vue.js directive is a JavaScript object that can have one or more of the following lifecycle properties. Each property is a method called at different stages of the lifecycle of the DOM element to which the directive is applied. This allows for the execution of specific actions at each stage:

1. beforeMount(el, binding): Called just before the element el is inserted into the DOM  
2. mounted(el, binding): Called when the element el has just been added to the DOM  
3. beforeUpdate(el, binding): Called before the element el is updated, for example, when a reactive variable changes  
4. updated(el, binding): Called after the element el has been updated

5. beforeUnmount(el, binding): Called just before the element el is removed from the DOM  
6. unmounted(el, binding): Called after the element el has been removed from the DOM

The primary method used among the aforementioned is the mounted() method. It runs once when the el element is attached to the DOM.

By using these methods, you can perform specific actions at different moments in the lifecycle of the element to which the directive is applied.

Each of these methods accepts two parameters: el and binding:

el: The DOM element associated with the directive (the one on which the directive is placed).

binding: An object containing additional information about the directive. This object can have several properties, such as the following:

binding.value: The value passed to the directive (the value is indicated after the “=” sign if present after the directive).  
binding.arg: The argument passed to the directive, if used. The argument is separated by the “:” character with the directive. Only one argument can be specified. For example, for the v-bind:value directive, binding. arg is "value".  
binding.modifiers: An object representing the modifiers applied to the directive. Multiple modifiers can be specified, separated by “.”.  
binding.instance: The instance of the component using the directive.  
binding.dir: An object containing information about the directive itself.

One might ask: Where to place a directive?

According to the official Vue.js documentation, directives are primarily designed to be applied to DOM nodes, that is, HTML elements. Although it is possible to apply a directive to a Vue.js component, this use is not explicitly encouraged or recommended by Vue.js.

## Creating a New Directive

To create a new directive, we use the app.directive(name, callback) method. The app object is returned by the createApp(App) method. The createApp(App) method is used in the src/main.js file of the application and is used to create the Vue.js application.

The newly created directives will be centralized from the src/main. js file. They can be either directly specified in this file or imported from a file that contains them. Let’s explore these two possibilities by creating a focus directive that will be used in the form of v-focus in the component templates. This v-focus directive is designed to give focus to the HTML element to which it is applied, such as an input field.

Note that we define the directive in JavaScript programs under the name focus but use it in templates with the name v-focus.

## Step 1: Creating the Directive in the src/ main.js File

Let’s start with the simplest case of inserting the focus directive directly into the src/main.js file. The src/main.js file becomes as follows:

## Focus directive (file src/main.js)

import { createApp } from 'vue'; import App from './App.vue';

```javascript
const focusDirective = {
    mounted(el) {
    el.focus();
    }
};
const app = createApp(App);
// Creation of the directive within the application
app.directive("focus", focusDirective);
app.mount('#app');
```

The file main.js is modified to retrieve the value of the variable app returned by the createApp(App) method. Subsequently, the app. directive() method is employed to create a new directive usable within the application.

The mounted(el) method is utilized to define the directive. This method is invoked in the lifecycle of the directive when the associated DOM element el is inserted into the DOM.

The directive is then employed in the MyCounter component, which displays an input field with the v-focus directive applied.

MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>
</script>

<template>

<h3>MyCounter Component</h3>
Counter value : <input v-focus />

</template>
```

The App component displays the MyCounter component:

App component (file src/App.vue)  
```vue
<script setup>
import MyCounter from './components/MyCounter.vue'
</script>
<template>
<MyCounter />
</template>
```

Let’s launch the application. The input field gains focus automatically without the need for a click.

![](images/a383191aad31b38999e8953aa7a8fa38023afb92b32c82991e71225126d28cad.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Counter value :
</details>

Figure 5-1. Directive v-focus

We have seen how to insert the new directive directly into the src/ main.js file. However, it is more practical to use another file to avoid modifying, for each added directive, this crucial file for the application’s operation.

## Step 2: Creating the Directive in a Directives File

Let’s now explore another way of defining directives without having to modify the src/main.js file for each new directive added, as done previously.

Create the src/directives.js file that will contain our new directives. This file will be imported into the src/main.js file. Modify the src/main. js file to consider the directives defined in the src/directives.js file.

The src/directives.js file containing the focus directive is as follows:

Focus directive (file src/directives.js)  
```javascript
const focusDirective = {
    mounted(el) {
    el.focus();
    }
};
export default {
    focus : focusDirective,
}
```

The directive is defined as an object, focusDirective, as previously explained. The export default statement is used to convey this functionality to files that utilize it. In this case, it is the src/main.js file that leverages the content of src/directives.js. Here is the description of this file:

Creating the directives defined in src/directives.js (file src/main.js)  
```javascript
import { createApp } from 'vue';
import App from './App.vue';
import directives from "./directives.js"
```

```javascript
const app = createApp(App);
```

```javascript
for (let name in directives) {
    // Creation of the directive name within the application
    app.directive(name, directives[name]);
}
app.mount('#app');
```

The directives.js file is imported, and the obtained directives variable is an object of the form { focus, ... }. We iterate through the properties of this object and use the app.directive(name) method on each property name of the object. This way, only the src/directives.js file will be modified later to add new directives. The src/main.js file will no longer need modification when adding a new directive.

However, it is even more advantageous to place each directive in a separate file, as explained in the following.

## Step 3: Creating the Directive in a Separate File

A variation of the previously created directives file would be to externalize each directive into a separate file. The src/directives.js file would then only need to import the external file associated with each directive.

Let’s create the focus.js file associated with the v-focus directive. Also, create the src/directives directory that will contain files for each directive, each created in a separate file.

Focus directive (file src/directives/focus.js)  
```javascript
const focusDirective = {
    mounted(el) {
    el.focus();
    }
```

```txt
};
```

export default focusDirective;

The directive file must be imported into the src/directives.js file:

## Importing the focus directive (file src/directives.js)

import focus from "./directives/focus";

```javascript
export default {
    focus,
}
```

If you want to import other directives, you just need to add them to the src/directives.js file in the same manner. The other files, App. vue and MyCounter.vue, remain identical to the previous versions. The functionality remains unchanged.

![](images/68b3379f6e77ab0b90f8e3b54e8178b933ccab12ad4fcad18a4732860db7860f.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Counter value :
</details>

Figure 5-2. Directive v-focus in a separate file

To ensure greater maintainability of our Vue.js applications, this latter solution of writing directives in separate files offers better prospects for evolution. Let’s now explore some examples of writing directives using the various possibilities offered by Vue.js.

# Directive v-integers-only Allowing Only Numerical Input

Let’s illustrate our examples by creating a new directive that allows only numerical input in an input field. We will name this directive v-integers-only.

We will use this directive in different forms:

1. v-integers-only: This is the simplest form of the directive. Used in this way, the directive signifies that only digits from 0 to 9 can be used in the input field.  
2. v-integers-only.hexa: When the hexa modifier is used, it means modifying the basic behavior of the directive to also allow hexadecimal characters, that is, the letters from “a” to “f” or “A” to “F”.  
3. v-integers-only.hexa.upper: The upper modifier is used here in addition to the hexa modifier. It means replacing, during input, the characters “a” to “f” with the characters “A” to “F”. Thus, the input “123abc” becomes “123ABC”.

Let’s see how to write these different forms of using the v-integersonly directive.

## Step 1: Directive in the Form v-integers-only

Let’s start by writing the simplest form of the directive. When this directive is present for an input field, it only allows entering digits from 0 to 9 in the field. Any other character, except for movement arrows, is not considered.

Note that we had already created a component that only allowed entering digits in the input field (see Chapter 3). However, we used events to manage the input field, which complicated the writing of the component. Here, we propose moving the event handling to the directive rather than the component.

As a reminder, the MyCounter component was as follows:

MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>
import { ref } from "vue"
const count = ref();
const verifyKey = () => {
    const numbers = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
    const moves = ["Backspace", "ArrowLeft", "ArrowRight", "Delete", "Tab", "Home", "End"];
    let authorized; // Allowed keys in the input field
    authorized = [...numbers, ...moves];
    // If the key is not allowed, do not take it into account.
    // The event object is available here.
    if (!authorized.includes(event.key)) event.preventDefault();
}
</script>
<template>
<h3>MyCounter Component</h3>

Reactive variable count: <input type="text" @keydown="verifyKey()" v-model="count" />
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```vue
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

The verifyKey() method, placed on the <input> element, filtered keyboard keys to allow only digits or movement and deletion keys.

Let’s create a directive that performs the same treatment. For this purpose, we create the directive file src/directives/integers-only.js, which is then included in the global src/directives.js file.

Directive v-integers-only (file src/directives/integers-only.js)  
```javascript
const integersOnly = {
    mounted(el) {
    el.addEventListener("keydown", (event) => {
    const numbers = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
    const moves = ["Backspace", "ArrowLeft", "ArrowRight", "Delete", "Tab", "Home", "End"];
    let authorized; // Allowed keys in the input field
    authorized = [...numbers, ...moves];
    // If the key is not allowed, do not take it into account.
    // The event object is available here.
    if (!authorized.includes(event.key)) event.preventDefault();
    });
    },
}
export default integersOnly;
```

We use the addEventListener() method defined in the DOM to listen for the keydown event on the DOM element el passed as a parameter to the mounted(el) method. The rest of the directive’s program is similar to what was done when writing the MyCounter component.

The directive is integrated into the directives file src/directives.js:

Adding the directive to the directives file (file src/directives.js)  
```typescript
import focus from "./directives/focus";
import integersOnly from "./directives/integers-only";
export default {
    focus,
    integersOnly, // It will be used in the form of v-integers-only
}
```

The directive is exported as integersOnly but will be used in the form v-integers-only. Note that using it as v-integersOnly also works but is not recommended.

We use this directive in the MyCounter component, which becomes simpler than before:

Using the v-integers-only directive (file src/components/ MyCounter.vue)  
```vue
<script setup>
import { ref } from "vue"
const count = ref();
</script>
<template>
<h3>MyCounter Component</h3>
```

```vue
Reactive variable count: <input type="text" v-focus v-integers-only v-model="count" />
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

We are simultaneously using the two newly created directives: v-focus and v-integers-only.

![](images/f7d3b6caad90e75ed2cf9e86cb23c764573d8aa2c6f95e13dda65db5f606d3f3.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 123
Entered value: 123
</details>

Figure 5-3. Using the v-integers-only directive

Only numeric characters and movement arrows are now allowed in the input field.

## Step 2: Directive in the Form v-integers -only.hexa

An improvement to the v-integers-only directive would be to allow input of hexadecimal characters in the field. Instead of writing a new directive (with a new name, e.g., v-integers-hexa-only), Vue.js allows using the same directive name by associating what it calls modifiers. It is sufficient to indicate the name of the modifier used after the directive, separated by a “.”.

The hexa modifier, used in the form v-integers-only.hexa, allows modifying the behavior of the v-integers-only directive to also allow hexadecimal characters in the field, in addition to the digits 0 to 9.

Let’s see how to modify the v-integers-only directive to take into account the hexa modifier when used in the directive.

Each of the lifecycle methods of a directive accepts, as a second argument, the binding parameter, for example, mounted(el, binding). The binding parameter contains additional information about the directive, such as binding.modifiers, which is an object indicating the modifiers used in writing the directive.

Thus, if binding.modifiers.hexa is true, it means that the hexa modifier is used in the directive.

The v-integers-only directive is modified to account for this hexa modifier:

Considering the hexa modifier in the v-integers-only directive (file src/ directives/integers-only.js)  
```javascript
const integersOnly = {
    mounted(el, binding) {
    el.addEventListener("keydown", (event) => {
    const numbers = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
    const moves = ["Backspace", "ArrowLeft", "ArrowRight", "Delete", "Tab", "Home", "End"];
    const letters = ["a", "b", "c", "d", "e", "f", "A", "B", "C", "D", "E", "F"];
```

let authorized; // Allowed keys in the input field

```javascript
// Allow hexadecimal characters if the hexa modifier is present
if (binding.modifiers.hexa) authorized = [...numbers, ...letters, ...moves];
else authorized = [...numbers, ...moves];

    // If the key is not allowed, do not take it into account.
    // The event object is available here.
    if (!authorized.includes(event.key)) event.
    preventDefault();
    });
},
}

export default integersOnly;
```

The MyCounter component uses this new form of the directive:

Using the v-integers-only.hexa directive (file src/components/ MyCounter.vue)  
```vue
<script setup>
import { ref } from "vue"
const count = ref("");
</script>
<template>
<h3>MyCounter Component</h3>
```

Reactive variable count: <input type="text" v-focus v-integersonly.hexa v-model="count" />

```vue
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

We verify that the input field now accepts hexadecimal characters in addition to the digits 0 to 9:

![](images/0ffd88b99d792c3931c47545464ce554d9e442eef0bf70c3aae75d038e0c96a7.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 123ABCDEF
Entered value: 123ABCDEF
</details>

Figure 5-4. Considering the hexa modifier in the v-integers-only directive

## Step 3: Directive in the Form v-integers-only.hexa.upper

The upper modifier allows entering characters that will be displayed in uppercase. Thus, the hexadecimal characters “a” to “f” will be transformed and displayed as “A” to “F”.

Let’s modify the MyCounter component to use the upper modifier.

MyCounter component with the upper modifier (file src/components/ MyCounter.vue)

```txt
<script setup>
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```vue
import { ref } from "vue"
const count = ref("123abcDEF");
</script>
<template>
<h3>MyCounter Component</h3>
Reactive variable count: <input type="text" v-model="count" v-focus v-integers-only.hexa.upper />
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

Note that we positioned the v-model directive first in the input field. Indeed, directives are processed by Vue.js in the order they appear in an element. This allows, first and foremost, to initialize the content of the field with the value of the associated reactive variable, thanks to v-model. The content of the field can then be used by the following directives, which would not be possible if the v-model directive were written at the end.

The v-integers-only directive is modified to account for the upper modifier.

Considering the upper modifier in the directive (file src/directives/ integers-only.js)  
```txt
const integersOnly = {
    mounted(el, binding) {
    if (binding.modifiers.upper) {
    // Convert the displayed field to uppercase with an initial value
    }
}
```

```dart
// (for this to work, the v-model directive must be written before this one in the input field)
el.value = el.value.toUpperCase();
// Simulate an input event to mimic a keyboard keypress
// (necessary for the reactive variable linked to the field to be updated)
el.dispatchEvent(new Event("input"));
}
```

```javascript
el.addEventListener("keydown", (event) => {
    const numbers = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
    const letters = ["a", "b", "c", "d", "e", "f", "A", "B", "C", "D", "E", "F"];
    const moves = ["Backspace", "ArrowLeft", "ArrowRight", "Delete", "Tab", "Home", "End"];
    let authorized; // Allowed keys in the input field
```

```javascript
// Allow hexadecimal characters if the hexa modifier is present
if (binding.modifiers.hexa) authorized = [...numbers, ...letters, ...moves];
else authorized = [...numbers, ...moves];
```

```javascript
// If the key is not allowed, do not take it into account if (!authorized.includes(event.key)) event.
preventDefault();
```

```txt
// Handle the upper modifier
if (binding.modifiers.upper) {
    // If the key is a hexadecimal letter, convert it to uppercase
```

```typescript
if (letters.includes(event.key)) {
    const start = el.selectionStart;
    const end = el:mm:sselseEnd;
    const text = el.value;

    // Insert the character at the cursor position
    const newText = text.substring(0, start) + event.key + text.substring(end);
    // Update the value of the input field (in uppercase)
    el.value = newText.toUpperCase();
    // Move the cursor after the inserted character
    el.setSelectionRange(start + 1, start + 1);

    // Prevent further processing of the key (as it has already been handled above)
    event.preventDefault();

    // Simulate an input event to mimic a keyboard keypress
    // (necessary for the reactive variable linked to the field to be updated)
    el.dispatchEvent(new Event("input"));
    }
    }
    });
},
export default integersOnly;
```

The upper modifier complicates the writing of the directive! Indeed, we have to handle the insertion of the pressed key into the field ourselves to display it in uppercase.

# Directive v-max-value Limiting the Maximum Value in an Input Field

We want to improve the management of the previous input field by limiting the value entered in the field, using a directive called v-max-value.

We will use this directive in one of the following forms:

1. v-max-value: Used in this form, the maximum value is considered to be 100. Beyond that, the input field turns red.  
2. v-max-value="max": The max value refers to a max variable (reactive or not) defined in the program. If this value is exceeded, the input field turns red.  
3. v-max-value.bold="max": When present in the directive, the bold modifier additionally makes the value entered in the input field bold if the max value is exceeded.

Let’s see how to write these different forms of using the v-max-value directive.

## Step 1: Directive in the Form v-max-value

The first form of the directive is the simplest. It assumes that the maximum value of the field is a fixed value of 100.

The MyCounter component that uses this directive is as follows:

Using the v-max-value directive (file src/components/MyCounter.vue)

```typescript
<script setup>  
import { ref } from "vue"  
const count = ref("");
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```vue
</script>
<template>
<h3>MyCounter Component</h3>
Reactive variable count: <input type="text" v-model="count" v-integers-only v-focus v-max-value />
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

The order of directive usage is crucial. The v-max-value directive is placed after the v-model directive: indeed, the v-model directive initializes the input field, which the v-max-value directive can then read.

The file for the v-max-value directive is src/directives/maxvalue.js.

v-max-value directive (file src/directives/max-value.js)  
```javascript
const maxValue = {
    mounted(el) {
    const value = el.value || 0; // Value in the field
    if (value > 100) el.style.color = "red";
    else el.style.color = "";
    },
    updated(el) {
    const value = el.value || 0; // Value in the field
    if (value > 100) el.style.color = "red";
    else el.style.color = "";
    },
}
export default maxValue;
```

We are utilizing the mounted() and updated() lifecycle methods. Specifically, during the mounted() phase, it is imperative to validate that the value transmitted for the input field initialization does not exceed the value of 100. This validation must also be conducted during each update of the field within the updated() method.

The procedures within these two methods are identical. Consequently, it is plausible to consolidate the processing into a function named treatment(), invoked within both mounted() and updated().

Other form of the directive (file src/directives/max-value.js)  
```javascript
const treatment = (el) => {
    const value = el.value || 0; // Value in the field
    if (value > 100) el.style.color = "red";
    else el.style.color = "";
}

const maxValue = {
    mounted(el) {
    treatment(el);
    },
    updated(el) {
    treatment(el);
    },
}

export default maxValue;
```

The v-max-value directive is inserted into the src/directives.js file:

File src/directives.js  
```typescript
import focus from "./directives/focus";
import integersOnly from "./directives/integers-only";
import maxValue from "./directives/max-value";
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```txt
export default {
    focus,
    integersOnly,
    maxValue,
}
```

Let us verify that this is functional. As soon as the input value exceeds 100, the input field should change its color to red.

![](images/3234a195e0bd33b5726a501fa15c317aec8504f2fb647a0d7037b9f4e15cec55.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 101
Entered value: 101
</details>

Figure 5-5. v-max-value directive

# Step 2: Directive in the Form v-max-value=“max”

Instead of setting the field’s limit to a fixed value (here 100), it is also possible to transmit this value within the directive (after the “=” sign).

The max value indicated here corresponds to the value of a variable (reactive or nonreactive) initialized earlier in the program.

The MyCounter component utilizing this form of the directive becomes the following:

MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>
import { ref } from "vue"
const count = ref("201");
const max = 200;
</script>
<template>
<h3>MyCounter Component</h3>
Reactive variable count: <input type="text" v-model="count" v-integers-only v-focus v-max-value="max" />
<br/><br/>
Max value: <b>{{max}}</b>
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

The maximum value of the field is initialized here to the value of 200. The v-max-value directive is modified to handle the value assigned to it.

v-max-value directive (file src/directives/max-value.js)  
```txt
const treatment = (el, binding) => {
    const maxValue = binding.value || 100; // 100 by default
    const value = el.value || 0; // Value in the field
    if (value > maxValue) el.style.color = "red";
    else el.style.color = "";
}
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```javascript
const maxValue = {
    mounted(el, binding) {
    treatment(el, binding);
    },
    updated(el, binding) {
    treatment(el, binding);
    },
}
export default maxValue;
```

The value assigned to the directive in the template is retrieved using binding.value. If the value is not specified, it defaults to 100 as before.

The input field will turn red as soon as the value of 200 is exceeded in the input field (here, when it reaches 201):

![](images/121b8ba476b72719221508d0eb31eca6c2ed20d87ef47ce41e9cbbc14d4a8745.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 201
Max value: 200
Entered value: 201
</details>

Figure 5-6. v-max-value=“max” Directive

# Step 3: Directive in the Form v-max-value. bold=“max”

This form of the directive is similar to the previous one, but we integrate the bold modifier, which changes the appearance of the input field (making it bold) when the field value exceeds the maximum allowed value:

If the bold modifier is absent from the directive, the behavior is similar to that of the previous example.  
• If the bold modifier is present in the directive, the input field is made bold when the maximum value is exceeded. The previous behavior of the directive is also retained (the input field turns red if the value is exceeded).

Let’s see how to use this new form of the directive in the MyCounter component:

MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>
import { ref } from "vue"
const count = ref("201");
const max = 200;
</script>
<template>
<h3>MyCounter Component</h3>
Reactive variable count: <input type="text" v-model="count" v-integers-only v-focus v-max-value.bold="max" />
<br/><br/>
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```txt
Max value: <b>{{max}}</b>
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

The directive is modified to incorporate the consideration of the bold modifier:

Bold modifier in the v-max-value directive (file src/directives/maxvalue.js)  
```javascript
const treatment = (el, binding) => {
    const maxValue = binding.value || 100; // 100 by default
    const value = el.value || 0; // Value in the field
    const bold = binding.modifiers.bold;
    if (value > maxValue) {
    el.style.color = "red";
    if (bold) {
    el.style.fontWeight = "bold";
    el.style.fontFamily = "arial";
    }
    }
    else {
    el.style.color = "";
    el.style.fontWeight = ""; // Removal of "bold"
    el.style.fontFamily = ""; // Removal of "arial"
    }
}
const maxValue = {
    mounted(el, binding) {
    treatment(el, binding);
},
```

```javascript
updated(el, binding) {
    treatment(el, binding);
},
export default maxValue;
```

When the maximum value is exceeded, we set the font to “bold” and also modify it to “Arial” to make the change even more noticeable on the screen.

![](images/0467201a6731dc8a30b27c8ca17d2d0f6dc89da3b3eea9bf2a95616d296a6de9.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 201
Max value: 200
Entered value: 201
</details>

Figure 5-7. Utilization of the “bold” modifier in the directive

The maximum value of 200 having been exceeded, the input field has turned red and bold.

## v-focus Directive for Giving Focus

We have previously created this directive in the preceding pages, using it in the form v-focus. We will use the v-focus directive in one of the following forms:

1. v-focus: This simplest form of the directive gives focus to the input field on which the directive is applied. We have used this form previously.

2. v-focus:color="color": This form of the directive allows specifying a value for the color argument of the directive. The input field gains focus, and the text color becomes the one indicated in the color variable.

3. v-focus:backcolor="bcolor": This form of the directive allows indicating a value for the backcolor argument of the directive. The input field gains focus, and the background color of the text becomes the one indicated in the bcolor variable.

4. v-focus:colors="colors": This form of the directive allows specifying in the colors variable, in the form { color, backgroundcolor }, the text and background colors of the input field when it gains focus.

To enable us to learn additional aspects of directives, we wish to explain here the use of arguments in directives.

## Step 1: What Is an Argument in a Directive?

An argument is used after the directive’s name, separated by the “:”

symbol. For example, we write v-focus:color="'blue'", to indicate that the text color should be blue when the element has focus.

In this case, we say that the v-focus directive has an argument named color, with its value set to "blue".

What is the difference between "'blue'" and "blue"? Note that here we specify the value as "'blue'" and not just "blue". Indeed, if we write it as "blue", it refers to a variable (reactive or nonreactive) named blue, while we intend to assign the string "blue", hence the notation "'blue'". What is written within the string “” must be a JavaScript expression, which is the case with 'blue'.

Why use an argument in a directive? One might think that we could simply write the directive as v-focus="'blue'". However, this is less precise than writing v-focus:color="'blue'" because we might also want to write v-focus:backgroundcolor="'yellow'" to change the background color in that case.

The argument’s name (color, backgroundcolor) helps specify the type of value indicated in the directive, especially when multiple types of values are possible (color, backgroundcolor).

What is the difference between a modifier and an argument? A modifier specifies a behavior in a directive, while an argument provides a value (for that argument). We use an argument to indicate a value and a modifier to specify a specific behavior (making it bold, uppercase, etc.).

Is an argument necessary? If the directive’s value type is unique (e.g., always a maximum value, a color, etc.), there is no need to use an argument. In this case, it suffices to indicate a value to the directive without specifying the argument to which the value corresponds. The argument in a directive serves only to specify what the value corresponds to (color, backgroundcolor).

Now that we have clarified that, let’s use this information to enhance the v-focus directive with new functionalities.

## Step 2: Directive in the Form v-focus

This form of the directive is the one we previously wrote. We rewrite it here to show how it will evolve based on the arguments used later.

The MyCounter component uses the v-focus directive:

Utilization of the v-focus directive in the MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>
import { ref } from "vue"
const count = ref("12345");
</script>
<template>
<h3>MyCounter Component</h3>
Reactive variable count: <input type="text" v-model="count" v-focus />
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

The v-focus directive is described as follows:

v-focus directive (file src/directives/focus.js)  
```javascript
const focusDirective = {
    mounted(el) {
    el.focus();
    },
};
export default focusDirective;
```

When the MyCounter component is displayed, the input field immediately gains focus.

![](images/fa2f6494f4dd7d4d67e01532ac226f36c86b871bb728c4ee4e21cd902eab3ca7.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 12345
Entered value: 12345
</details>

Figure 5-8. The input field gains focus

## Step 3: Directive in the Form v-focus:color=“color”

This form of the directive allows specifying a value for the directive. As this value is a color, an additional color argument is used to specify the type of the value. Later, we will see that we can also use the arguments backgroundcolor and colors to indicate other types of values, hence the use of arguments to specify the type of value used.

The MyCounter component using this form of the directive is as follows:

MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>
import { ref } from "vue"
const count = ref("12345");
const color = "cyan";
</script>
<template>
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```txt
<h3>MyCounter Component</h3>

Reactive variable count: <input type="text" v-model="count"
    v-focus:color="color" />

<br/><br/>
Entered value: <b>{{count}}</b>

</template>
```

The directive is specified here in the form v-focus:color="color" because color is a variable defined in the program. If we were to directly specify a value in the directive (without using a variable name), we would write it in the form v-focus:color="'cyan'" as explained earlier.

The directive file is modified to accommodate this new argument:

v-focus directive with the color argument (file src/directives/focus.js)  
```javascript
const focusDirective = {
    mounted(el, binding) {
    el.focus();
    const arg = binding.arg;
    const value = binding.value;
    if (arg == "color") el.style.color = value;
    }
};
export default focusDirective;
```

The input field gains focus, and the input field’s color changes to “cyan”.

![](images/e2e07e9ac715c4e056299c850ff344ae7ed28b06a57be68261e1a654a5fa02be.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 12345
Entered value: 12345
</details>

Figure 5-9. Input field with focus and cyan color

Note in this example that the input field retains its new color even if the input field loses focus. It would be necessary to restore the previous color of the input field when it loses focus.

To achieve this, we need to handle the focus and blur events on the input field. Let’s modify the directive for that purpose.

Handling the focus and blur events in the v-focus directive (file src/ directives/focus.js)  
```javascript
const focusDirective = {
    mounted(el, binding) {
    const arg = binding.arg;
    const value = binding.value;
    // Position the handling of the focus and blur events
    el.addEventListener("focus", () => {
    if (arg == "color") el.style.color = value;
    });
    el.addEventListener("blur", () => {
    if (arg == "color") el.style.color = "";
    }
}
```

```javascript
});
// and then give focus to the input field
el.focus();
}
};
export default focusDirective;
```

We modify the color of the input field upon entering the field (focus event) and then restore the initial color upon leaving the field (blur event). Additionally, we give focus to the input field only after positioning the event handlers; otherwise, they would not be considered during the initial display of the component.

Let’s verify that this is functional. Upon launching the program, the input field gains focus, and the color of the input field is modified:

![](images/08897220028545faa0ef9c086d9b5a7fc74ea590287c498f7d77b83c369649b6.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 12345
Entered value: 12345
</details>

Figure 5-10. Gaining focus in the input field

Then click outside the input field. The color of the input field is removed.

![](images/d9377262ad5ec1a0f20dc3e358d11c5d53fadc3fa17a6f9c91dab3db2d9881dc.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 12345
Entered value: 12345
</details>

Figure 5-11. The input field has lost focus

This form of the v-focus directive, using the focus and blur events, will be retained in the following examples.

## Step 4: Directive in the Form v-focus:backgroundcolor=“bcolor”

Another form of the v-focus directive uses the backgroundcolor argument to specify a background color in the directive.

The modifications to the MyCounter component and the directive are similar to those previously made to use the color argument.

The MyCounter component using the backgroundcolor argument in the v-focus directive becomes the following:

MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>  
import { ref } from "vue"  
const count = ref("12345");  
const color = "cyan";  
</script>
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```vue
<template>
<h3>MyCounter Component</h3>

Reactive variable count: <input type="text" v-model="count"
    v-focus:backgroundcolor="color" />

<br/><br/>
Entered value: <b>{{count}}</b>

</template>
```

The v-focus directive implementing the backgroundcolor argument becomes the following:

v-focus directive using the backgroundcolor argument (file src/ directives/focus.js)  
```javascript
const focusDirective = {
    mounted(el, binding) {
    const arg = binding.arg;
    const value = binding.value;
    // Position the handling of the focus and blur events
    el.addEventListener("focus", () => {
    if (arg == "color") el.style.color = value;
    if (arg == "backgroundcolor") el.style.backgroundColor = value;
    });
    el.addEventListener("blur", () => {
    if (arg == "color") el.style.color = "";
    if (arg == "backgroundcolor") el.style.backgroundColor = "";
    });
    }
);
```

```javascript
// and then give focus to the input field
el.focus();
}
};
export default focusDirective;
```

We have simply added the handling of the backgroundcolor argument in a similar fashion to that of the color argument.

The MyCounter component is now displayed:

![](images/eb77f7074820b5339879ddfa2221fea23e9b694d1c9e8643f4171e8e25f4dd4b.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 12345
Entered value: 12345
</details>

Figure 5-12. Utilization of the backgroundcolor argument in the v-focus directive

## Step 5: Directive in the Form v-focus:colors=“colors”

The v-focus directive now has both the color and backgroundcolor arguments. However, only one of the two can be specified when using the directive.

Hence, the creation of the new colors argument, which allows specifying the values of both arguments in the form of an object { color, backgroundcolor }.

The MyCounter component becomes the following:

MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>
import { ref } from "vue"
const count = ref("12345");
const colors = { color:"cyan", backgroundcolor:"black" };
</script>
<template>
<h3>MyCounter Component</h3>
Reactive variable count: <input type="text" v-model="count" v-focus:colors="colors" />
<br/><br/>
Entered value: <b>{{count}}</b>
</template>
```

The v-focus directive is modified to use this new argument, in addition to the two others:

v-focus directive (file src/directives/focus.js)  
```javascript
const focusDirective = {
    mounted(el, binding) {
    const arg = binding.arg;
    const value = binding.value;
    // Position the handling of the focus and blur events
    el.addEventListener("focus", () => {
    if (arg == "color") el.style.color = value;
```

```javascript
if (arg == "backgroundcolor") el.style.backgroundColor = value;
if (arg == "colors") {
    el.style.color = value.color;
    el.style.backgroundColor = value.backgroundColor;
}
});
el.addEventListener("blur", () => {
    if (arg == "color") el.style.color = "";
    if (arg == "backgroundcolor") el.style.backgroundColor = "";
    if (arg == "colors") {
    el.style.color = "";
    el.style.backgroundColor = "";
    }
});
// and then give focus to the input field
el.focus();
};
export default focusDirective;
```

The MyCounter component now takes into account a new text and background color for the input field:

![](images/81c7aed5b10c249e2e6e48a0abf1d06abdf0d078f4fdf2a89f0a302e45a68958.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 12345
Entered value: 12345
</details>

Figure 5-13. Utilization of the colors argument in the v-focus directive

# v-clearable Directive for Adding a Clear Button to the Input Field

Let’s now demonstrate a new directive that adds a Clear button after an input field, allowing the user to clear the input field’s content. The v-clearable directive inserts the button directly after the input field.

The MyCounter component using the directive would be as follows:

MyCounter component using the v-clearable directive (file src/ components/MyCounter.vue)

```vue
<script setup>
import { ref } from "vue"
const count = ref("Text to be cleared");
</script>
<template>
<h3>MyCounter Component</h3>
```

Reactive variable count: <input type="text" v-model="count" v-clearable v-focus />

<br/><br/>

Entered value: $< b > \{ \{ \mathsf { c o u n t } \} \} < / \mathsf { b } >$

</template>

We display an input field with the v-clearable directive in the template. When the directive v-clearable will be written, the component will appear as follows:

![](images/75c1d2133dc8aa28bf63e3ec20caac18bfbed36e3d34670d4098c2dbe903b0b6.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: Text to be cleared
Clear
Entered value: Text to be cleared
</details>

Figure 5-14. Input field with a Clear button

Clicking the Clear button clears the content of the input field:

![](images/7486849f9950989c0a4d8d962fc9cf9aec149e1cff55a2e2521f51fc7dd50cad.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count:
Clear
Entered value:
</details>

Figure 5-15. The input field has been cleared

The v-clearable directive is written in the file src/directives/ clearable.js:

v-clearable directive (file src/directives/clearable.js)  
```javascript
const clearable = {
    mounted(el) {
    const clearButton = document.createElement("button");
    clearButton.innerHTML = "Clear";
    clearButton.style = "position:relative; left:10px";

    // Handle the click on the button (clear the content of the input field).
    clearButton.addEventListener("click", () => {
    // Clear the content of the input field.
    el.value = "";
    // Simulate an input event to mimic a keyboard key press
    // (mandatory to ensure that the reactive variable linked to the input field is updated)
    el.dispatchEvent(new Event("input"));
    // Give focus to the input field
    el.focus();
    }
}
```

```javascript
});
// Insert the button after the input field
el.parentNode.insertBefore(clearButton, el.nextSibling);
};
export default clearable;
```

The v-clearable directive is then inserted into the file src/ directives.js:

File src/directives.js  
```javascript
import focus from "./directives/focus";
import integersOnly from "./directives/integers-only";
import maxValue from "./directives/max-value";
import clearable from "./directives/clearable";
export default {
    focus,
    integersOnly,
    maxValue,
    clearable,
}
```

The v-clearable directive is now ready for being used.

## v-timer Directive for Displaying Real-Time Clock

The v-timer directive replaces the content of the element it is applied to with the current time in the format HH:MM:SS. It has several derived forms:

1. v-timer: This is the simplest form of the directive. It displays the current time in real time, in the format HH:MM:SS.  
2. v-timer.ms: The ms modifier of the directive allows displaying tenths of a second after the seconds.  
3. v-timer.chrono: The chrono modifier starts a stopwatch in the format HH:MM:SS starting from 00:00:00. It increments every second, or every tenth of a second if the ms modifier is present.

Let’s see how to implement these different forms of the v-timer directive.

## Step 1: Directive in the Form v-timer

The MyCounter component using this directive can be written as follows:

Utilization of the v-timer directive (file src/components/ MyCounter.vue)

```erb
<script setup>
</script>
<template>
<h3>MyCounter Component</h3>
```

It is <span v-timer />

```vue
</template>
```

The content of the <span v-timer> element will be replaced by the current time in the format HH:MM:SS.

The v-timer directive is created in the file src/directives/timer.js:

v-timer directive (file src/directives/timer.js)  
```javascript
const timer = {
    mounted(el) {
    // Initialization of the displayed time
    // (allows it to be displayed immediately without waiting for a second)
    let time = getCurrentTime();
    el.innerHTML = time;
    setInterval(() => {
    // Then incrementing the time every second
    let time = getCurrentTime();
    el.innerHTML = time;
    }, 1000); // Every 1000 milliseconds (1 second).
    },
}

function getCurrentTime() {
    // Return the current time in the format HH:MM:SS
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds Las...
}

export default timer;
```

The getCurrentTime() method returns the current time in the format HH:MM:SS. This time is then displayed in the el element using the v-timer directive. The setInterval(callback) method, with the processing function called every second (1000 milliseconds), refreshes the displayed time.

To function, the directive must be included in the src/directives.

js file:  
Insertion of the directive (file src/directives.js)  
```javascript
import focus from "./directives/focus";
import integersOnly from "./directives/integers-only";
import maxValue from "./directives/max-value";
import clearable from "./directives/clearable";
import timer from "./directives/timer";

export default {
    focus,
    integersOnly,
    maxValue,
    clearable,
    timer,
}
```

Let’s verify that the time is incremented every second:

![](images/ebf9958931a99c4527e412cfac6ee827fb0468d588fbd44f635187c86df181bc.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
It is 13:48:05
</details>

Figure 5-16. Displaying the time with the v-timer directive

## Step 2: Directive in the Form v-timer.ms

Another form of the directive allows for more precision by also displaying tenths of a second. For this, the ms modifier is used following the v-timer directive.

The v-timer directive is modified:

Using the ms modifier in the v-timer directive (file src/directives/ timer.js)  
```javascript
const timer = {
    mounted(el, binding) {
    const ms = binding.modifiers.ms;
    let time = getCurrentTime(ms);
    el.innerHTML = time;
    setInterval(() => {
    let time = getCurrentTime(ms);
    el.innerHTML = time;
    }, 100);
    },
}

function getCurrentTime(ms = false) {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    let formattedTime = `${hours}:${minutes}:${seconds Lases};
    if (ms) {
    const milliseconds = now.getMilliseconds().toString().
    slice(0, 1); // Obtaining tenths of a second
    formattedTime += `.${milliseconds Lases};
    }
}
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```javascript
return formattedTime;
}
export default timer;
```

The getCurrentTime() function is modified to consider the optional ms parameter, indicating to format the time by adding tenths of a second at the end. The ms modifier is taken into account in the v-timer directive, through binding.modifiers.ms, which is true if the ms modifier is present, false otherwise.

Let’s use both forms of the v-timer directive in the MyCounter component:

MyCounter component (file src/components/MyCounter.vue)  
```erb
<script setup>
</script>
<template>
<h3>MyCounter Component</h3>
```

```vue
It is <span v-timer />
<br>
It is <span v-timer.ms /> more precisely
</template>
```

The displayed result is as follows:

![](images/454c397150c06dbf2dd055a41ec58d43997117b8181a23e1eada4b80feb41506.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
It is 14:17:26
It is 14:17:26.7 more precisely
</details>

Figure 5-17. Using both forms of the v-timer directive

The first timer displays the time every second, while the second displays the time every tenth of a second.

## Step 3: Directive in the Form v-timer.chrono

The chrono modifier in the v-timer directive allows immediately starting a stopwatch.

The MyCounter component file is modified to display it:

Display a stopwatch (file src/components/MyCounter.vue)  
```html
<script setup>
</script>
<template>
<h3>MyCounter Component</h3>
It is <span v-timer />
<br>
It is <span v-timer.ms /> more precisely
<br>
<br>
```

Elapsed time <span v-timer.chrono />  
```html
<br> Elapsed time <span v-timer.chrono.ms /> more precisely
```

```vue
</template>
```

The ms modifier can be used with the chrono modifier to add more precision to the elapsed time. The processing of the chrono modifier is inserted into the v-timer directive file:

Using the chrono modifier in the v-timer directive (file src/directives/ timer.js)  
```javascript
const timer = {
    mounted(el, binding) {
    const ms = binding modifiers.ms;
    const chrono = binding modifiers.chrono;

    // Initialization of the clock or stopwatch.
    if (!chrono) {
    let time = getCurrentTime(ms);
    el.innerHTML = time;
    }
    else {
    if (!ms) el.innerHTML = "00:00:00";
    else el.innerHTML = "00:00:00.0";
    }

    setInterval(() => {
    if (!chrono) {
    let time = getCurrentTime(ms);
    el.innerHTML = time;
    }
    else {
    const chronoTime = getChronoTime(ms);
    }
}
```

```javascript
el.innerHTML = chronoTime;
},
}, 100);
},
}

function getCurrentTime(ms = false) {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    let formattedTime = `${hours}:{minutes}:{seconds Lasars}
    if (ms) {
    const milliseconds = now.getMilliseconds().toString().
    slice(0, 1); // Obtaining tenths of a second
    formattedTime += `.${milliseconds}`;
    }
    return formattedTime;
}
```

## let startChronoTime = new Date(); // Starting time of the stopwatch

```javascript
function getChronoTime(ms = false) {
    const now = new Date();
    const elapsedMilliseconds = now.getTime() - startChronoTime.
    getTime();

    const hours = Math.floor(elapsedMilliseconds / (3600 * 1000));
    const remainingMilliseconds1 = elapsedMilliseconds % (3600 * 1000);
```

Chapter 5 Day 5: Mastering the Creation of Direc tives in Vue.js  
```javascript
const minutes = Math.floor(remainingMilliseconds1 / (60 * 1000));
const remainingMilliseconds2 = remainingMilliseconds1 % (60 * 1000);

const seconds = Math.floor(remainingMilliseconds2 / 1000);

let formattedTime = `${hours.toString().padStart(2, '0')}:{minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}';

if (ms) {
    const milliseconds = Math.floor(remainingMilliseconds2 % 1000);
    const tenthsOfSecond = Math.floor((milliseconds % 1000) / 100);
    formattedTime += `.${tenthsOfSecond.toString()}`;
}

return formattedTime;
}

export default timer;
```

Following the same principle as the getCurrentTime() function, we create the getChronoTime() function, which allows retrieving the elapsed time in the format HH:MM:SS. After a certain time, the display becomes the following:

![](images/310a8d17bbea6b1e7fe7aaf8514bec586f7066c120beb2d73a5add4ab08a4ea0.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
It is 14:25:54
It is 14:25:54.1 more precisely
Elapsed time 00:02:20
Elapsed time 00:02:20.8 more precisely
</details>

Figure 5-18. Displays of the v-timer directive

## Conclusion

We have explained how to create new directives in Vue.js, simplifying the code of our Vue.js components. Thanks to arguments and modifiers, Vue. js directives offer incredible functionalities that allow simple and intuitive use in components.

# Day 6: Mastering the Creation of Composables in Vue.js

As seen in the previous chapter, creating new directives makes it easier to manipulate the HTML elements on which the directives are used. In this chapter, we will explore composables. Composables are also known as composition functions.

Composables defined in our Vue.js components are used to encapsulate application logic in the form of reusable functions. Thus, they are oriented toward internal component logic and data management.

## Why Create Composables?

Creating composables in a Vue.js application is useful for several reasons, as described in the following:

1. Reusability of Code: Composables allow grouping functionalities into reusable modules. This means writing the functionality once and using it in multiple components of the application without repeating it.  
2. State Management: Composables are particularly useful for managing the application state. State management is encapsulated in a composition function, making data management more consistent and predictable. It also facilitates handling the global state of the application.  
3. Ease of Testing: Composables are easy to test in isolation.  
4. Scalability: Composables promote the scalability of the application. New features can be added or existing logic modified in a composition function without having to modify many components.

Composables are a powerful tool for improving the structure, maintainability, and code reuse in Vue.js.

## Differences Between Composables and Directives

Creating composables allows us to write Vue.js component code better, much like directives also allow. However, directives and composables are not used in the same way.

Directives help write HTML code within the <template> section of components, simplifying this code to the maximum.

Composables help write JavaScript code within the <script setup> section of the component, allowing the use of functionalities defined in the functions called composables.

Therefore, with the ability to write new directives and create composables, Vue.js enables us to write the entire code that creates Vue.js components more effectively.

## Creating a Vue.js Composable

A Vue.js composable is a JavaScript function. Like any function, it may have optional input parameters and may return a result.

A composable is meant to provide a service. We create a composable when we have identified a service to provide in our component. This service may also be used in other components, making our composable even more useful.

Because a composable is meant to provide a service, it is customary to start its name with the word "use", followed by the name given to the composable.

For example:

1. useCounter(): This composable manages actions in a component like MyCounter (incrementing, decrementing the counter).  
2. useFetch(): This composable performs an HTTP request and retrieves information from a remote server.

Thus, to create a composable, you must first ask the following questions:

1. What are its parameters?  
2. What data or functionalities does it return?

These questions help identify the parameters and return of the JavaScript function associated with the composable. These are the questions to ask whenever you want to create a new composable.

As a composable can be used in several components, tradition dictates grouping composables in the composables directory within the src directory.

Let’s see, with a simple example, how to create the useCounter() composable to manage the MyCounter component.

## Step 1: Creating the useCounter( ) Composable

The useCounter() composable manages the increment and decrement of the counter associated with the MyCounter component.

Without using composables, the MyCounter component we wrote in Chapter 1 was as follows:

MyCounter component (file src/components/MyCounter.vue)  
```vue
<script setup>
import { ref } from 'vue';
const count = ref(0);
const increment = () => {
    count.value++;
}
const decrement = () => {
    count.value--;
}
</script>
```

```vue
<template>
<h3>MyCounter Component</h3>
Reactive variable count : <b>{{ count }}</b>
<br /><br />
<button @click="increment">count+1</button>
&nbsp;
<button @click="decrement">count-1</button>
</template>
```

The increment() and decrement() functions of the counter are defined in the <script setup> section of the component. They are then used in the <template> section of the component.

The idea behind composables is to externalize data management into external functions called composables. These composable functions will then be available and used in components that require them.

In the case of the MyCounter component, we externalize the management of the count variable, including its increment and decrement, into a composable named useCounter().

Let’s examine the parameters and possible returns of the useCounter() composable. Thus, the useCounter() composable:

1. Will have an init parameter, which is the initialization value of the counter.  
2. Will return as data the current value count of the counter (managed within the composable, hence made available as a return value), and the functions increment() and decrement() allowing to increment or decrement the counter value. These elements will be accessible in the component that uses this composable.

Let’s write the MyCounter component that uses the useCounter() composable.

Usage of the useCounter() composable in the MyCounter component (file src/components/MyCounter.vue)

```txt
<script setup>
```

import useCounter from "../composables/useCounter.js"

const [count, increment, decrement] = useCounter(0); // 0 = Initialization of the counter

```vue
</script>

<template>

<h3>MyCounter Component</h3>

Reactive variable count : <b>{{ count }}</b>
<br /><br />

<button @click="increment">count+1</button>
&nbsp;
<button @click="decrement">count-1</button>
</template>
```

The <script setup> section of the MyCounter component has now become simpler, thanks to the use of the useCounter() composable:

1. The useCounter() composable is first imported into the component.  
2. The useCounter(0) function of the composable is called with the initialization value 0 and returns, in the form of an array, the values [count, increment, decrement], which, respectively, correspond to the current value of the counter and the increment() and decrement() functions of the counter.

The count variable is then used in the template of the component, as well as the increment() and decrement() functions, which are called when clicking the “count+1” or “count-1” button of the component.

The useCounter() composable is created in the useCounter.js file in the src/composables directory. It is written as follows:

useCounter() composable (file src/composables/useCounter.js)  
```javascript
import { ref } from "vue";
const useCounter = (init) => {
    const count = ref(init);
    const increment = () => {
    count.value++;
    }
    const decrement = () => {
    count.value--;
    }
    return [count, increment, decrement];
}
export default useCounter;
```

It is evident that the complete management of the reactive variable count is integrated into the composable, which streamlines the code of the MyCounter component.

Let us verify that the component functions:

![](images/0600aae054f50061a4273b37d28b9eec7f5d3f6e20b4e73e204148469d38552d.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count : 6
count+1 count-1
</details>

Figure 6-1. useCounter() composable

## Step 2: Return Composable Data As an Array or As an Object?

In the previous example, we observed that the useCounter() composable returns an array [count, increment, decrement]. Alternatively, we could have returned an object {count, increment, decrement}.

## Usage As an Array

If we use return [count, increment, decrement] in the composable, we dictate the order of the elements returned in the array. They must then be used in the same order, but not necessarily under the same names, in the component using the composable.

Thus, in the MyCounter component, we could write the following: const [count1, increment1, decrement1] = useCounter(0);

Then, the count1 variable and the increment1() and decrement1() functions can be used in the component.

Moreover, if an element returned by the composable is not used in the component, it can be written as follows:

If the MyCounter component does not use the increment() function returned by the composable:

const [count, , decrement] = useCounter(0); // increment is not used

## Usage As an Object

If we use return {count, increment, decrement} in the composable, the names used in the returned object cannot be changed during their usage. However, the order of properties in the object no longer matters.

Thus, in the MyCounter component, we could write the following: const {decrement, increment, count} = useCounter(0);

The order of the returned elements is changed, but not their names because the names of object properties are not modifiable, while their order of appearance does not matter. Therefore, an object {key1, key2} is equivalent to an object {key2, key1}.

Thus, a composable can return data as an array or as an object, with the constraints mentioned previously. However, in the examples that follow, it will be seen that it is more judicious to return data as an array rather than as an object.

## Improving a Vue.js Composable

We will now see how, based on a previous composable, it is possible to enhance it to provide new functionalities.

We will start with the useCounter() composable and create two new composables that will be used in the MyCounter component. These are the following composables:

1. useCounterMax(): This composable allows setting a maximum value for the counter, not to be exceeded.  
2. useCounterMaxWithError(): This composable is similar to the previous one but also displays an error message if attempting to exceed the maximum value.

Let’s start by creating the useCounterMax() composable.

## Step 1: useCounterMax( ) Composable

This composable is used in the form useCounterMax(init, max) and allows blocking the incrementation of the counter when it reaches a maximum value indicated in the parameters.

The MyCounter component using this composable is written as follows:

Usage of the useCounterMax() composable in the MyCounter component (file src/components/MyCounter.vue)

```txt
<script setup>
import useCounterMax from "../composables/useCounterMax"
const init = 1;
const max = 5;
const [count, increment, decrement] = useCounterMax(init, max);
</script>
<template>
<h3>MyCounter Component</h3>
Reactive variable count: <b>{{ count }}</b>
<br><br>
Maximum value: <b>{{max}}</b>
```

```vue
<br /><br />
<button @click="increment">count+1</button>
&nbsp;
<button @click="decrement">count-1</button>
</template>
```

The code of the MyCounter component is almost identical to the previous one. We have only imported the new useCounterMax() composable, and we display the maximum value not to exceed in the template.

The useCounterMax() composable returns the same information as the previous useCounter() composable:

The count variable corresponds to the value of the reactive variable.  
The increment() function increments the variable if possible (i.e., if the maximum value is not reached).  
The decrement() function decrements the variable.

Let’s write the new useCounterMax(init, max) composable. It utilizes the previously written useCounter(init) composable.

useCounterMax() composable (file src/composables/ useCounterMax.js)  
```typescript
import useCounter from "../composables/useCounter";
const useCounterMax = (init, max) => {
    const [count, increment, decrement] = useCounter(init);
    const incrementMax = () => {
    if (count.value >= max) {
    return; // Avoid incrementing
    }
    else {
```

```txt
increment(); // Increment
}
}
return [count, incrementMax, decrement];
}
export default useCounterMax;
```

The new useCounterMax() composable uses the old useCounter() composable. Only the increment() function is modified, named incrementMax() here to differentiate it. If the maximum value is reached, we do not increment; otherwise, we increment by calling the old increment() function available in the old useCounter() composable.

Because we return the composable data as an array, it is sufficient to respect the order of the returned data in the new composable, even if their names are different. Thus, we return incrementMax(), but you can use the name increment() in the component using it, which avoids modifying the MyCounter component (outside of the name of the used composable).

Let’s verify that this works:

![](images/82b7f83b4dd52401c90bd48809c2de5500b9f537bd7c8f3f335d1746edc38dea.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 5
Maximum value: 5
count+1 count-1
</details>

Figure 6-2. Usage of the useCounterMax() composable

The counter is blocked at the maximum value, which cannot be exceeded.

# Step 2: useCounterMaxWithError( ) Composable

Let’s enhance the useCounterMax() composable by allowing it to display an error message if attempting to exceed the maximum value.

This will be the role of the new useCounterMaxWithError() composable, which displays an error message in this case.

The input parameters are init and max.  
The returned data is an array [count, increment, decrement, error], where error corresponds to a reactive variable that will display the error message.

The MyCounter component is now written as follows:

Usage of the useCounterMaxWithError composable (file src/ components/MyCounter.vue)

<script setup>

import useCounterMaxWithError from "../composables/ useCounterMaxWithError"

```txt
const init = 1;
const max = 5;
const [count, increment, decrement, error] = useCounterMaxWithError(init, max);
</script>
<template>
<h3>MyCounter Component</h3>
Reactive variable count: <b>{{ count }}</b>
<br><br>
Maximum value: <b>{{max}}</b>
```

Chapter 6 Day 6: Mastering the Creation of Com posables in Vue.js  
```txt
<br><br>
```  
Error: <b>{{error}}</b>

```vue
<br /><br />
<button @click="increment">count+1</button>
&nbsp;
<button @click="decrement">count-1</button>
</template>
```

The useCounterMaxWithError() composable is written as follows:

useCounterMaxWithError() composable (file src/composables/ useCounterMaxWithError.js)  
```typescript
import useCounter from "../composables/useCounter";
import { ref } from "vue";
const useCounterMaxpliers = (init, max) => {
    const [count, increment, decrement] = useCounter(init);
```  
const error = ref("");

```javascript
const incrementMax = () => {
    if (count.value >= max) {
    error.value = "Maximum value reached!";
    }
    else {
    increment();
    error.value = "";
    }
}
const decrementMax = () => {
    decrement();
    if (count.value <= max) {
    error.value = "";
    }
```

```txt
}
return [count, incrementMax, decrementMax, error];
}
```

export default useCounterMaxWithError;

Using a reactive variable, defined as const $\mathrm { e r r o r ~ } = \mathrm { ~ r e f } ( ^ { \mathfrak { m } } )$ , is essential for displaying the error message because it allows for reactivity in the user interface. Vue.js leverages reactivity to efficiently update the DOM when the underlying data changes. When a simple variable is used (e.g., let error), changes to that variable within the program may not be reflected on the screen.

Let’s verify that this works:

![](images/82df7ab124a2c0208d69effd43240ca2cc27e01725ec5002fbd06cd734693f51.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 5
Maximum value: 5
Error: Maximum value reached!
count+1 count-1
</details>

Figure 6-3. Display of the error message in the composable

As soon as the max value is exceeded, the error is displayed.

# Step 3: Improved useCounterMaxWithError ( ) Composable

The previous composable functions correctly. However, if the initial value is set to a value higher than the max value, no error message is displayed.

Let’s write these values into the MyCounter component:

## Initialization (file src/components/MyCounter.vue)

const init = 10;

const max = 5; // init > max

This displays the following result:

![](images/a93e74fb300f8cc690791d09e5004a67c468e2e5f69e1dd6ceba2ff9e0e96601.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 10
Maximum value: 5
Error:
count+1 count-1
</details>

Figure 6-4. Initial counter value higher than the maximum value: no error displayed

To remedy this, the composable should test the values passed by the component during its initialization. A composable has access to all the functionalities of a component, particularly its lifecycle through methods such as onMounted(), onUpdated(), etc. These are the lifecycle methods of a Vue.js component that were described in Chapter 1.

Let’s use the onMounted() method, which allows for processing when the component is mounted in the DOM.

The useCounterMaxWithError() composable becomes the following:

Utilization of the onMounted() method in the composable (file src/ composables/useCounterMaxWithError.js)  
```javascript
import useCounter from "../composables/useCounter";
import { ref, onMounted } from "vue";

const useCounterMaxWithError = (init, max) => {
    const [count, increment, decrement] = useCounter(init
    const error = ref("");
    const incrementMax = () => {
    if (count.value >= max) {
    error.value = "Maximum value reached!";
    }
    else {
    increment();
    error.value = "";
    }
    }
    const decrementMax = () => {
    decrement();
    if (count.value <= max) {
    error.value = "";
    }
    }
    onMounted(() => {
    if (count.value > max) error.value = "Maximum value reached!";
    });
```

Chapter 6 Day 6: Mastering the Creation of Com posables in Vue.js

return [count, incrementMax, decrementMax, error]; }

export default useCounterMaxWithError;

Let us verify that the error is now displayed when the initial value of the counter exceeds the maximum value:

![](images/29a0e1c38bbb27ce808f46eb407ad1454d45d8996afdab640b59e1feec216390.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Reactive variable count: 10
Maximum value: 5
Error: Maximum value reached!
count+1 count-1
</details>

Figure 6-5. Error message displayed during initialization

## Utility Composables

Following the same principle as the useCounter() composable (and its derived composables), let’s write other composables that will serve as utility composables, as they can be used in various applications. These include the following:

1. useFetch(): Performs an HTTP request.  
2. useWindowSize(): Determines the size of the window.  
3. useGeolocation(): Determines the current geolocation.

Let’s start with the first proposed composable, which is useFetch().

## useFetch( ) Composable for Performing an HTTP Request

The useFetch(url) composable allows for making an HTTP request to a specified URL (url parameter) using the fetch(url) method defined in JavaScript. The composable returns a startFetch() method that initiates the HTTP request, and the asynchronous result will be returned by the startFetch() method.

Let’s create the MyCountries component that utilizes the useFetch() composable to retrieve results. We will use the URL https:// restcountries.com/v3.1/all, which was employed in Chapter 4 to fetch the list of countries worldwide.

## MyCountries component using the useFetch() composable (file src/ components/MyCountries.vue)

```vue
<script setup>
import useFetch from "../composables/useFetch"
import { ref } from "vue";
const data = ref();
const url = "https://restcountries.com/v3.1/all";
const [startFetch] = useFetch(url);
const initData = async () => {
    data.value = await startFetch();
}
</script>
```

Chapter 6 Day 6: Mastering the Creation of Com posables in Vue.js  
```vue
<template>
<button @click="initData">Start Fetch</button>
<br><br>
<b>Data</b> : {{data}}
</template>
```

The MyCountries component utilizes the useFetch() composable, hence the import statement import useFetch.

The useFetch() composable returns the startFetch() method, allowing the initiation of data retrieval from the server using the URL provided in useFetch(url).

The “Start Fetch” button on the page triggers the data retrieval, which will be displayed in the reactive variable data. To achieve this, the initData() method is created, called upon clicking the button. This method invokes the startFetch() method obtained from the composable, and the startFetch() method returns the data read from the server. To manage the asynchronous nature of exchanges between the client and the server, the async and await keywords of JavaScript are utilized within this method.

Let us now write the useFetch() composable used in the MyCountries component. As indicated previously, it should return an asynchronous startFetch() function that retrieves data from the server in JSON format.

useFetch() composable (file src/composables/useFetch.js)  
```javascript
const useFetch = (url) => {
    const startFetch = async () => {
    const res = await fetch(url);
    const d = await res.text();
    return JSON.parse(d); // Returning the data read from the server in JSON format
}
```

```javascript
return [startFetch];
}
export default useFetch;
```

The App component is, of course, modified to integrate the MyCountries component:

App component (file src/App.vue)  
```vue
<script setup>
import MyCountries from './components/MyCountries.vue'
</script>
<template>
<MyCountries />
</template>
```

Let’s run the program. The MyCountries component will be displayed with the “Start Fetch” button:

![](images/93c006995ded01491641cb8ab28f52857c7c700f5d50501496f9d1986d3b7e3f.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
Start Fetch
Data :
</details>

Figure 6-6. MyCountries component

Clicking on the “Start Fetch” button retrieves the list of countries from the server and displays it as a table in the reactive data variable.

![](images/dfc628cd6d294cbeb99f7c0f790ead403c9bc1d46d7b2b8e8fbdb0a54250c1fc.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
Start Fetch
Data : [ { "name": { "common": "Christmas Island", "official": "Territory of Christmas Island", "nativeName": { "eng": { "official": "Territory of Christmas Island", "common": "Christmas Island" } } }, "tld": [ ".cx" ], "cca2": "CX", "ccn3": "162", "cca3": "CXR", "independent": false, "status": "officially-assigned", "unMember": false, "currencies": { "AUD": { "name": "Australian dollar", "symbol": "$" } }, "idd": { "root": "+6", "suffixes": ["1"] }, "capital": [ "Flying Fish Cove" ], "altSpellings": [ "CX", "Territory of Christmas Island" ], "region": "Oceania", "subregion": "Australia and New Zealand" , "languages": "/ang": "English" }.
</details>

Figure 6-7. List of retrieved countries displayed by the useFetch() composable

## useFetchCountries( ) Composable Derived from useFetch( )

The previous useFetch() composable serves as a starting point to create another composable specifically designed to display only the country names, which are located in the name.common properties of each array element.

The new composable is named useFetchCountries(url). It utilizes the previous url parameter and returns a fetchCountries() function that retrieves an array containing the names of the countries, sorted alphabetically.

The MyCountries component is modified to accommodate the newly used composable:

MyCountries component (file src/components/MyCountries.vue)  
```vue
<script setup>
import useFetchCountries from "../composables/useFetchCountries"
import { ref } from "vue";
const data = ref();
const url = "https://restcountries.com/v3.1/all";
const [startFetch] = useFetchCountries(url);
const initData = async () => {
    data.value = await startFetch();
}
</script>
<template>
<button @click="initData">Start Fetch</button>
<br><br>
<b)data</b> : {{data}}
</template>
```

Note that the name of the function returned by the composable can remain the same as before, as only the position in the returned array is relevant, as we have previously explained.

The new useFetchCountries(url) composable is written as follows:

useFetchCountries composable (file src/composables/ useFetchCountries.js)  
```javascript
import useFetch from "./useFetch";
const useFetchCountries = (url) => {
    const [startFetch] = useFetch(url);
    let countries;
```

Chapter 6 Day 6: Mastering the Creation of Com posables in Vue.js  
```javascript
const startFetchCountries = async () => {
    const data = await startFetch();
    countries = data.map(function(elem) {
    return elem.name.common; // Retain only the common.name property
    });
    // In ascending alphabetical order
    countries = countries.sort((n1, n2) => {
    if (n1 > n2) return 1;
    if (n1 < n2) return -1;
    return 0;
    });
    return countries;
    }
    return [startFetchCountries];
}

export default useFetchCountries;
```

The useFetchCountries() composable utilizes the useFetch() composable. The new function startFetchCountries() provided by the composable returns an array of all country names, ordered in ascending alphabetical order.

Let’s see if it works after clicking the “Start Fetch” button:

![](images/6362ee8f2f6caeaab26ddc8119b86364b09b0980ce8757669d8107510fcf8445.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
Start Fetch
Data : ["Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "British Virgin Islands", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Caribbean Netherlands", "Cayman Islands", "Central African
</details>

Figure 6-8. List of retrieved country names displayed as an array

Now that the useFetchCountries() composable provides a function that returns country names as a JavaScript array, we can modify the MyCountries component to display the list of countries as an HTML list. The v-for directive in Vue.js will allow us to achieve this.

The MyCountries component is thus modified:

Display countries as an HTML list (file src/components/ MyCountries.vue)  
```typescript
<script setup>
import useFetchCountries from "../composables/useFetchCountries"
import { ref } from "vue";
const data = ref();
const url = "https://restcountries.com/v3.1/all";
const [startFetch] = useFetchCountries(url);
const initData = async () => {
    data.value = await startFetch();
}
```

Chapter 6 Day 6: Mastering the Creation of Com posables in Vue.js  
```vue
</script>

<template>

<button @click="initData">Start Fetch</button>
<br><br>

<b>Data</b> : 
<ul>
<li v-for="(country, i) in data" :key="i">{{country}}</li>
</ul>

</template>
```

The list of countries is now displayed in HTML format:

![](images/075dd01ca92eba52e72dd38db2b9bc6f8ae4f99e0309e8d914efc832ccbf3979.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
← → ↙ ↕ localhost:8080 ☆ ↗ ≡
Start Fetch
Data :
• Afghanistan
• Albania
• Algeria
• American Samoa
• Andorra
• Angola
• Anguilla
</details>

Figure 6-9. List of countries displayed in HTML format

## useWindowSize( ) Composable for Real-Time Window Size Information

The useWindowSize() composable returns a reactive variable, windowSize, represented by an object { width, height }, indicating the width and height of the window in which the application is running, respectively.

If the window is resized, the reactive variable windowSize updates in real time.

The useWindowSize() composable is created in the src/composables directory.

useWindowSize() composable (file src/composables/ useWindowSize.js)  
```javascript
import { ref, onMounted, onBeforeUnmount } from "vue";
const useWindowSize = () => {
    const windowsize = ref({
    width: window.width,
    height: window.width,
    });
    const updateWindowSize = () => {
    windowsize.value = {
    width: window.width,
    height: window.width,
    };
    };

    onMounted(() => {
    window.addEventListener('resize', updateWindowSize);
    });

    onBeforeUnmount(() => {
    window.addEventListener('resize', updateWindowSize);
    });

    return windowsize;
}

export default useWindowSize;
```

The useWindowSize() composable returns the reactive variable windowSize. It is not placed in an array since it is the sole value returned by the composable.

The composable is utilized in the MyCounter component.

Usage of the useWindowSize() composable (file src/components/ MyCounter.vue)  
```vue
<script setup>
import useWindowSize from '../composables/useWindowSize';
const windowSize = useWindowSize();
</script>
<template>
<h3>MyCounter Component</h3>
Window size: <b>{{windowSize}}</b>
</template>
```

The App component displays the MyCounter component:

App component (file src/App.vue)  
```vue
<script setup>
import MyCounter from './components/MyCounter.vue'
</script>
<template>
<MyCounter />
</template>
```

As the window is resized, the new dimensions are displayed in real time within the window:

![](images/cbcae400b621128f207e313bcf1614c24c70d9c2b776d5ca95f3d61aedbd95a0.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:8080
MyCounter Component
Window size: { "width": 450, "height": 233 }
</details>

Figure 6-10. Usage of the useWindowSize() composable

The useWindowSize() composable serves as a starting point to crea format and determining whether to display the application on a mobile phone or a conventional website.

# useGeolocation( ) Composable for Obtaining User Latitude and Longitude

The useGeolocation() composable will be valuable for determining the geographical location of the user.

useGeolocation() composable (file src/composables/ useGeolocation.js)

import { ref, onMounted } from "vue";

Chapter 6 Day 6: Mastering the Creation of Com posables in Vue.js  
```javascript
const useGeolocation = () => {
    const latitude = ref(null);
    const longitude = ref(null);

    const handleGeolocation = (position) => {
    latitude.value = position.coords.latitude;
    longitude.value = position.coords.longitude;
    };

    const errorGeolocation = (error) => {
    console.log("Geolocation error:", error.message);
    };

    onMounted(() => {
    if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(handleGeolocation, errorGeolocation);
    } else {
    console.log("Geolocation is not available in this browser.");
    }
    });

    return [latitude, longitude];
}

export default useGeolocation;
```

We define two reactive variables, latitude and longitude, which will be returned by the composable. The browser’s geolocation API is utilized to retrieve the user’s GPS coordinates.

To initiate geolocation upon program startup, we use the onMounted() method of the composable, where the processing is performed.

The MyCounter component, which uses the composable and displays the returned data, is as follows:

Usage of the useGeolocation() composable (file src/components/ MyCounter.vue)  
```javascript
<script setup>
import useGeolocation from '../composables/useGeolocation';
const [latitude, longitude] = useGeolocation();
```

```vue
</script>
<template>
<h3>MyCounter Component</h3>
Latitude: <b>{{latitude}}</b>
<br>
Longitude: <b>{{longitude}}</b>
<br>
</template>
```

Let’s run the program. After granting the browser access to geolocation, we obtain the following:

![](images/1822643ad4b11aa846afe86044bc9315a2f77af53f24fd11240d39dcb78334fd.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:80
MyCounter Component
Latitude: 30.267153
Longitude: -97.7430608
</details>

Figure 6-11. Usage of the useGeolocation() composable

The latitude and longitude have been updated in the component.

## useGeolocationWithDetails( ) Composable Derived from useGeolocation( )

Let’s enhance the previous useGeolocation() composable by providing not only the latitude and longitude but also the corresponding country and city. For this purpose, we create the new composable useGeolocationWithDetails().

To achieve this, we use a new API from the site https://nominatim. openstreetmap.org/reverse. By specifying latitude and longitude in the URL, it returns a JSON object containing, among other things, the corresponding country and city.

For example, using the following URL in a browser: https:// nominatim.openstreetmap.org/reverse?format=json&lat=30.267153&l on=-97.7430608.

![](images/85cf1d485c6f7d92645dea0b5dc077b71eb076bf0519af02cff67c6463a0a187.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
nominatim.openstreetmap.org/reve X +
← → ↩ https://nominatim.o ☆ ↕ >> ≡
JSON Raw Data Headers
Save Copy Collapse All Expand All Filter JSON
place_id: 273287679
licence: "Data @ OpenStreetMap contributors, OObL 1.0. http://osm.org/copyright"
osm_type: "node"
osm_id: 3849775794
lat: "30.266924"
lon: "-97.742983"
class: "place"
type: "house"
place_rank: 30
importance: 0.00000399999999995449
addresstype: "place"
name: ""
display_name: "103, East 5th Street, Downtown, Austin, Travis County, Texas, 78701, United States"
address:
    house_number: "103"
    road: "East 5th Street"
    neighbourhood: "Downtown"
    city: "Austin"
    county: "Travis County"
    state: "Texas"
ISO3166-2-lvl4: "US-TX"
    postcode: "78701"
country: "United States"
country_code: "us"
</details>

Figure 6-12. Usage of the API https://nominatim.openstreetmap. org/reverse

The previous location indicates that we are located in the United States, in the city of Austin, Texas.

To implement this new composable, we will use the previous useGeolocation() composable, which provides the current latitude and longitude. Then, by passing these two values to the URL https:// nominatim.openstreetmap.org/reverse, we receive in return the country, city, etc., corresponding to the indicated GPS coordinates.

The MyCounter component is modified to use the new composable useGeolocationWithDetails() and display the country and city.

Display the country and city (file src/components/MyCounter.vue)  
```vue
<script setup>
import useGeolocationWithDetails from '../composables/
useGeolocationWithDetails';

const [latitude, longitude, country, city] =
useGeolocationWithDetails();

</script>

<template>

<h3>MyCounter Component</h3>

Latitude : <b>{{latitude}}</b>

<br>

Longitude : <b>{{longitude}}</b>

<br>

Country : <b>{{country}}</b>

<br>

City : <b>{{city}}</b>

<br>

</template>
```

The new useGeolocationWithDetails() composable returns an array [latitude, longitude, country, city]. Each value in the array corresponds to a reactive variable displayed in the component.

Let’s now write the useGeolocationWithDetails() composable. It utilizes the previous useGeolocation() composable to obtain the latitude and longitude to be used in determining the corresponding country and city.

useGeolocationWithDetails() composable (file src/composables/ useGeolocationWithDetails.js)  
```typescript
import { ref, watchEffect } from "vue";
import useGeolocation from '../composables/useGeolocation';
const useGeolocationWithDetails = () => {
    const [latitude, longitude] = useGeolocation();
    const country = ref("");
    const city = ref("");
```

```javascript
// To find the country and city corresponding to the
latitude/longitude
watchEffect(async ()=>{
    if (latitude.value && longitude.value) {
    const response = await fetch(
    `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude.value}&lon=${longitude.value}
    );
    const data = await response.json();
    if (data && data.address && data.address.country) {
    country.value = data.address.country;
    }
    if (data && data.address) {
    city.value = data.address.city || data.address.town;
    }
    }
});

return [latitude, longitude, country, city];
}

export default useGeolocationWithDetails;
```

The interesting part of this composable lies in using the watchEffect() method. When you write the statement const [latitude, longitude] = useGeolocation();, it doesn’t mean that the variables latitude and longitude are immediately initialized. We need to wait for geolocation to be performed in the useGeolocation() composable.

How do we know when these variables, latitude and longitude, have been initialized? Since they are reactive, we can observe their value changes using the watchEffect(callback) method. The callback function provided as a parameter is called on the initial invocation of watchEffect(). This allows Vue.js to determine the reactive variables used in the callback, which will be the ones observed.

Using the statement if (latitude.value && longitude.value) within watchEffect() indicates that we are observing the reactive variables latitude and longitude. The subsequent processing is straightforward. When these variables change, we retrieve the country name from the address.country field, and similarly, we could retrieve the city from the address.city or address.town fields.

The result is as follows:

![](images/a6972b05d0f614afe4b0375b17f80aa8d6db8c068b50f91f76fd5d42333b4c4d.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
localhost:80
MyCounter Component
Latitude : 30.267153
Longitude : -97.7430608
Country : United States
City : Austin
</details>

Figure 6-13. Usage of the useGeolocationWithDetails() composable

The country and city names are also displayed in the component.

## useMap( ) Composable for Displaying the GPS Location Map

Creating the useGeolocationWithDetails() composable gives us the idea to create a new composable for displaying the map of the location indicated by GPS coordinates. Let’s name this new composable useMap().

To display the map, we can use various APIs. Among them, we have chosen Leaflet because it does not require an API key to function.

## Step 1: Install the Leaflet API

To use Leaflet, simply install it with the npm install leaflet command. This command is executed from the directory of the Vue.js application (in this case, the vueapp directory).

![](images/d27874437c65c0a5cb8f51b0107c04377e4cd7a32959f56607f40a3161f8f057.jpg)

<details>
<summary>text_image</summary>

D:\Documents\node.js\vueapp>npm install leaflet
added 1 package, and audited 964 packages in 3s
5 vulnerabilities (4 moderate, 1 critical)
To address issues that do not require attention,
run:
    npm audit fix

To address all issues (including breaking change
s), run:
    npm audit fix --force

Run `npm audit' for details.
D:\Documents\node.js\vueapp>
</details>

Figure 6-14. Installing the Leaflet API in the Vue.js application

## Step 2: Using the Leaflet API

Leaflet uses a JavaScript API and CSS style files to function.

1. To use the JavaScript API, import Leaflet into our program using the statement import L from "leaflet". The methods of the Leaflet API are accessible through the L object.  
2. To use Leaflet’s CSS files, import them into the main index.html file of the application. The index.html file using Leaflet’s CSS files becomes as follows:

Using Leaflet styles in the Vue.js application (file src/public/ index.html)  
```erb
<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" href="<%= BASE_URL %>favicon.ico">
    <!-- To include the Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <title><%= htmlWebpackPlugin.options.title %></title>
</head>
<body>
    <noscript>
```

```erb
<strong>We're sorry but <%= htmlWebpackPlugin.options.
    title %> doesn't work properly without JavaScript
    enabled. Please enable it to continue.</strong>
</noscript>

<div id="app"></div>
<!-- built files will be auto injected -->
</body>
</html>
```

To include Leaflet’s CSS styles, you can use the <link> tag in the application.

Now, let’s explore how to use Leaflet in the useMap() composable.

## Step 3: Writing the useMap( ) Composable

To display a map, Leaflet requires the following:

1. The latitude and longitude of the location to be displayed  
2. The ID of the DOM element in which to display the map  
3. The desired zoom level to display the map

The useMap(latitude, longitude, idMap) composable displays the desired map in the DOM element with the specified idMap. By default, we will use a zoom level of 13.

In return, the composable provides the map object created by Leaflet. This object allows, for example, the use of the statement map.remove() to remove any previously displayed map in the specified DOM element.

The useMap() composable can be written as follows:

useMap composable (file src/composables/useMap.js)  
```javascript
import L from "leaflet"
const useMap = (latitude, longitude, idMap) => {
    const zoom = 13;

    // To position the map at the indicated location
    const map = L.map(idMap).setView([latitude, longitude], zoom);

    // To display the corresponding map
    L.tileLayer("https://a.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 20,
    }).addTo(map);

    // To display a marker on the map to indicate the specified location
    L.marker([latitude, longitude]).addTo(map);

    // We return the map object created by Leaflet return map;
}

export default useMap;
```

We modify the MyCounter component to use the useMap() composable:

Using the useMap() composable (file src/components/MyCounter.vue)  
```txt
<script setup>  
import useGeolocationWithDetails from "../composables/useGeolocationWithDetails.js"  
import useMap from "../composables/useMap.js"
```

import { onMounted, watchEffect } from "vue";

const [latitude, longitude, country, city] = useGeolocationWithDetails();

// The onMounted() method ensures that the "map" DOM element is correctly inserted into the DOM.

```typescript
onMounted(() = >{
    // The watchEffect() method waits for the latitude and longitude to be properly initialized.
    watchEffect(() = >{
    if (latitude.value && longitude.value) useMap(latitude.value, longitude.value, "map");
    });
});
```

```vue
</script>

<template>

<h3>MyCounter Component</h3>

<p>Map around the city: <b v-show="city">{{city}} - {{country}}</b></p>

<div id="map" />

</template>

<style scoped>
#map {
    height: 300px;
    width: 100%;
}

</style>
```

We are using the following two composables:

1. The useGeolocationWithDetails() composable retrieves the latitude, longitude, city, and country of the location where we are geolocated.  
2. The useMap() composable displays the map of the location obtained by the previous composable.

Additionally, we are using the onMounted() and watchEffect() methods of Vue.js:

1. The onMounted() method ensures that the DOM element associated with the map (defined by <div id="map" />) is correctly inserted into the DOM, as Leaflet cannot begin to display the map if this element is not present.  
2. The watchEffect(callback) method observes changes in the values of reactive variables used in the associated callback function. Since the latitude and longitude obtained by useGeolocationWithDetails() are not acquired sequentially, we observe the associated reactive variables.

Let’s verify the functionality of the program:

![](images/1693ea0e0b91cbe2cde665b5ff7a4284695bc438d1da0e6b9aca7a45513e09d5.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
+
-
MyCounter Component
Map around the city: Austin - United States
University of Texas at Austin 235A
235B
234C
234B
234C
234B
234C
234B
Loop 343
1st Street
Leaflet
</details>

Figure 6-15. Usage of the useMap() composable to display the map of the location

Now, let’s see how to enhance the program by creating a v-map directive that internally uses the useMap() composable.

# Step 4: v-map Directive Using the useMap( ) Composable

The previous program is functional. However, it requires writing instructions like the ones previously written in onMounted() or watchEffect(), which could be localized in a directive rather than within the component itself. This is the purpose of the new v-map directive.

You would use this directive in the MyCounter component as follows:

Using the v-map directive (file src/components/MyCounter.vue)  
```txt
<script setup>
```  
import useGeolocationWithDetails from "../composables/ useGeolocationWithDetails.js"

const [latitude, longitude, country, city] = useGeolocationWithDetails();  
```vue
</script>

<template>

<h3>MyCounter Component</h3>

<p>Map around the city: <b v-show="city">{{city}} - {{country}}</b></p>

<div v-map="{latitude:latitude,longitude:longitude}" id="map" />

</template>

<style scoped>
#map {
    height: 300px;
    width: 100%;
}

</style>
```  
The previous <div id="map" /> element is now written as  
<div v-map="{latitude:latitude,longitude:longitude}" id="map" />

This <div> element now uses the v-map directive, to which we pass the latitude and longitude returned by useGeolocationWithDetails() as its value. The v-map directive internally retrieves these values using the binding parameter through binding.value.latitude and binding. value.longitude.

It is worth noting that the component will be automatically refreshed when the v-map directive has its value changed, thanks to the reactive variables. Therefore, the map will be displayed with the final values of latitude and longitude when they are obtained by the useGeolocationWithDetails() composable.

The v-map directive utilizes the useMap() composable. It is written as follows:

v-map directive (file src/directives/map.js)  
```javascript
import useMap from "../composables/useMap.js"
const map = {
    updated(el, binding) {
    const latitude = binding.value.latitude;
    const longitude = binding.value.longitude;
    if (latitude && longitude) {
    if (el._map) el._map.remove();
    el._map = useMap(latitude, longitude, el.id);
    }
    else if (el._map) {
    el._map.remove();
    el._map = null;
    }
    }
}
export default map;
```

We use the updated() method of the directive’s lifecycle. We check whether the latitude and longitude are known, and if so, we display the map using the useMap() composable. The map object returned by useMap() is stored as a property of the DOM element (in el.\_map) to clear a previous map that may have been displayed in this element (otherwise, Leaflet returns an error).

To make the directive usable, it needs to be inserted into the directives.js file, as explained in the previous chapter:

Adding the v-map directive (file src/directives.js)  
```javascript
import focus from "./directives/focus";
import integersOnly from "./directives/integers-only";
import maxValue from "./directives/max-value";
import clearable from "./directives/clearable";
import timer from "./directives/timer";
import map from "./directives/map";

export default {
    focus,
    integersOnly,
    maxValue,
    clearable,
    timer,
    map,
}
```

Let’s verify the proper functioning of the entire system:

![](images/33bcddaecd29dc2d733e5f1c0d50cfb0bfc6bb400a18e75b28ad9708c3f19e50.jpg)

<details>
<summary>text_image</summary>

File Edit View History Bookmarks Tools Help
vueapp
+ -
MyCounter Component
Map around the city: Austin - United States
University of Texas at Austin 235A
235B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
235B
235A
235B
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234C
234B
234E
Leaflet
</details>

Figure 6-16. Usage of the v-map directive

## Conclusion

In this chapter, we explored in detail the creation and usage of composables in Vue.js. We discussed why composables are valuable and how they differ from directives, being complementary. We then followed the steps to create and enhance Vue.js composables, illustrating this through concrete examples.

We also discovered utility composables that facilitate the management of common tasks such as HTTP requests, monitoring window size, geolocation, and displaying maps.

One of the most interesting examples was the creation of the useMap() composable to display maps based on GPS location using the Leaflet API. We followed a step-by-step process to create this composable, gaining insights into how to integrate third-party libraries into Vue.js.

Finally, we saw how to use the composables we created by incorporating them into custom directives, such as v-map, to make their usage even more user-friendly.

In conclusion, composables are a powerful way to abstract reusable logic and simplify the development of Vue.js applications. They provide an elegant way to handle complexity while keeping the code clean and modular. By mastering the creation and usage of composables, you can significantly enhance your productivity in Vue.js development. The ball is in your court!

## CHAPTER 7

# JavaScript Reminders

Before delving into the world of Vue.js, it is important to recall the fundamentals of JavaScript. This section is intended to assist you in refreshing your memory and getting up to speed on the key concepts of JavaScript that are utilized throughout the book.

We will cover essential concepts such as variables, arrays, objects, arrow functions, and modules. Additionally, we will explore more advanced concepts like asynchronous functions.

If you are already familiar with JavaScript, this section will help you recall and ensure that you have the necessary basics to understand Vue.js code examples.  
If you are new to the world of JavaScript, this section will provide you with a solid foundation to comprehend the concepts used throughout the book.

Ready to reinforce your JavaScript knowledge? Let’s begin!

## Using the Keywords let and var in JavaScript

In JavaScript, let and var are two keywords used to declare variables. The main difference between them lies in the variable’s scope.

The var keyword has a function scope, meaning that the variable is accessible inside the function where it is declared, as well as anywhere inside that function.

For example:

Using var to define a variable  
```javascript
function example() {
    var x = 10;
    if (true) {
    var x = 20; // The variable x is accessible inside the function example()
    }
    console.log(x); // Displays 20
}
```

In this example, the variable x is declared inside the function example(), but it is also accessible within the if block, because var has function scope. Therefore, writing var x = 20; does not create a new variable, as the variable x was declared earlier and is directly accessible within the if block. By writing var x = 20;, we are only modifying the value of the previously created variable.

On the other hand, the let keyword has block scope, which means the variable is accessible only within the block in which it is declared and in all nested blocks inside that block.

For example:

Using let to define a variable  
```javascript
function example() {
    let x = 10;
    if (true) {
    let x = 20; // The variable x is accessible only within the "if" block
```

```txt
}
console.log(x); // Displays 10
}
```

In this example, the variable x is declared inside the function example(). However, the second declaration of x inside the if block creates a new variable x, which is accessible only within that block. The variable x outside the if block retains its initial value of 10.

In summary, the main difference between let and var is the variable’s scope: var has function scope, and let has block scope. It is generally recommended to use let rather than var in JavaScript code, as it provides better control over variable scope and helps avoid accidental variable reuse across different blocks.

## Using the const Keyword in JavaScript

In JavaScript, the const keyword is used to declare a variable that cannot be reassigned after its initial value has been assigned. It creates a variable with a constant, unchangeable reference to a value. This means that once a value is assigned to a const variable, you cannot reassign it to a different value later in the code.

Here’s an explanation of how the const keyword works and its key characteristics.

When declaring a variable using const, you must immediately assign a value to it. Unlike the var or let keywords, you cannot declare a const variable without initializing it.

## Declaration and Initialization

```javascript
const pi = 3.14159;
```

Once a value is assigned to a const variable, its value cannot be changed. Attempting to reassign a const variable will result in an error.

## Value Immutability

```javascript
const pi = 3.14159;
pi = 3.14; // This will result in an error
```

Like variables declared with let, const variables are block-scoped. They are only accessible within the block (enclosed by curly braces) where they are defined.

## Block Scope

```javascript
if (true) {
    const message = "Hello";
    console.log(message); // OK
}
console.log(message); // Error: 'message' is not defined
```

You cannot declare another variable with the same name in the same scope if you’ve already declared it with const.

## No Redeclaration

```javascript
const value = 42;
const value = 100; // Error: Identifier 'value' has already been declared
```

When using const with objects and arrays, the reference to the object or array itself is immutable, but the properties or elements within the object or array can still be modified.

## Modifying object’s properties and array’s elements

```javascript
const person = { name: "Alice", age: 30 };
person.age = 31; // Valid, modifies a property inside the object
const numbers = [1, 2, 3];
numbers.push(4); // Valid, adds an element to the array
```

In summary, the const keyword is used to declare variables that are meant to remain constant after their initial assignment. It ensures immutability of the variable reference, but the properties or elements within objects and arrays declared with const can still be modified. Use const for values that should not be changed throughout the scope of the variable.

## Manipulating Objects in JavaScript

In JavaScript, structuring and destructuring objects are techniques that allow for efficient data manipulation.

## Step 1: Structuring an Object

Structuring an object involves defining a data structure for that object. You can create an object with a list of properties and their corresponding values. For example, you can create a person object with properties like name, age, and city as follows:

## Creating the person object

```javascript
const person = {
    name: "Gaby",
    age: 40,
    city: "Austin"
};
```

This allows us to access the values person.name (which is “Gaby”), person.age (which is 40), and person.city (which is “Austin”).

## Step 2: Object Destructuring

Object destructuring, on the other hand, allows you to extract object properties and use them independently. For instance, you can extract the name and age properties from the person object as follows:

## Destructuring the person object

const { name, age } = person;

In this example, we create two variables, name and age, that correspond to properties of the same names in the person object. We can now use these variables independently of the rest of the object.

Destructuring can also be used to pass arguments to a function in a more concise way. For example, you can create a function that takes an object person as an argument and displays the person’s name and age:

## Using destructuring in function definition

function displayNameAge({ name, age }) { console.log(\`The name is \${name} and the age is \${age}\`); }

In this example, we use destructuring to extract the properties name and age from the person object that is passed as an argument. We can now call this function with the person object as follows:

## Using the function

displayNameAge(person);

This will display “The name is Gaby and the age is 40” in the console.

In summary, object structuring and destructuring in JavaScript are powerful techniques that allow for efficient and concise data manipulation.

## Step 3: Passing Objects As Function Parameters

In JavaScript, the notation { key1, key2 } is used in function parameters to perform object destructuring. This notation allows you to destructure a literal object by extracting the values associated with the specified properties and assigning them to variables with the same names as the properties.

Here’s an example to illustrate its usage:

Object as a function parameter  
```javascript
function displayDetails({ name, age }) {
    console.log(`Name: ${name}`);
    console.log(`Age: ${age}`);
}

const person = {
    name: "Gaby",
    age: 40,
    city: "Austin",
    profession: "Developer",
};

displayDetails(person); // Displays "Name: Gaby" and "Age: 40"
```

In this example, the displayDetails() function takes an object as a parameter and destructures the object to extract values associated with the name and age properties. The extracted values are then used to display the person’s details.

It’s important to note that if a specified property in the destructuring notation does not exist in the object, its value will be undefined.

Additionally, it’s possible to rename the extracted variables using the syntax { property: newVariable }.

In summary, the { key1, key2 } notation in function parameters allows for object destructuring, extracting values associated with specified properties. This leads to more concise and readable code, avoiding direct property access within the function body.

## Step 4: Using the “...” Notation with Objects

Let’s now explain the "..." (three consecutive dots) notation with objects. The "..." notation in JavaScript, also known as the spread or rest operator, is used to spread or gather the elements of an array or an object.

When used with an object, the "..." notation creates a shallow copy of the original object, including all its properties and their values. For example:

## Using the “..." notation with objects

```javascript
const object1 = { x: 1, y: 2 };
const object2 = { ...object1 };
console.log(object2); // { x: 1, y: 2 }
```

In this example, the "..." notation is used to spread the properties of object1 into object2. This creates a shallow copy of object1, with the same properties and values.

If you write const object2 = object1;, it does not do the same thing at all! This statement creates a variable object2 that has the same memory reference as object1, thus referencing the same content as object1. If you modify the content of object1 or object2, the other object will be modified in the same way.

The "..." notation can also be used to merge multiple objects into one. For example:

## Merging objects with “..."

```javascript
const object1 = { x: 1, y: 2 };
const object2 = { z: 3 };
```

```javascript
const object3 = { ...object1, ...object2 };
console.log(object3); // { x: 1, y: 2, z: 3 }
```

In this example, the "..." notation is used to merge the properties of objects object1 and object2 into a new object object3.

It’s important to note that the "..." notation creates only a shallow copy of the original object. If the object contains properties that are themselves objects or arrays, these properties are not deeply copied and are still shared between the original object and the copy (since it’s the references to objects or arrays that are copied, thus shared between the original object and the new object).

## Manipulating Arrays in JavaScript

In JavaScript, an array is a data structure that allows you to store and access multiple elements as an ordered list.

## Step 1: Structuring an Array

Structuring arrays in JavaScript refers to creating, initializing, and manipulating arrays to store and organize data.

Creating an array in JavaScript can be done in several ways. The most common way is to declare an empty array [] and add elements using the push() method. For example:

## Creating an array using the push() method

```javascript
let array = [];
array.push(1);
array.push(2);
array.push(3);
console.log(array); // [1, 2, 3]
```

Another common method to create an array is by using the array literal notation, which allows you to declare and initialize an array in a single step. For example:

## Creating an array using []

```javascript
let array = [1, 2, 3];
console.log(array); // [1, 2, 3]
```

## Step 2: Array Destructuring

Array destructuring in JavaScript refers to extracting elements from an array into separate variables. This feature is useful for manipulating arrays in a more concise and readable manner. For example:

## Array destructuring into separate variables

```txt
let array = [1, 2, 3];
let [firstElement, secondElement, thirdElement] = array;
console.log(firstElement); // 1
console.log(secondElement); // 2
console.log(thirdElement); // 3
```

## Step 3: Using the “...” Notation with Arrays

Destructuring also allows you to retrieve a portion of an array using the "..." syntax. For example:

## Destructuring an array using the "..." notation

```javascript
let array = [1, 2, 3, 4, 5];
let [a, b, ...rest] = array;
console.log(a); // 1
console.log(b); // 2
console.log(rest); // [3, 4, 5]
```

In this example, the "..." notation is used to retrieve the remaining elements of the array after assigning the first two elements to the variables a and b. The variable rest will contain the elements 3, 4, and 5 as an array, that is, [3, 4, 5].

## Using Import and Export of Modules in JavaScript

In JavaScript, modules are code files that can contain functions, variables, and classes, which can be imported and used in other code files. Modules allow for structuring and organizing JavaScript code, making it more modular and easier to maintain.

There are several ways to define and import modules in JavaScript, but the most common method is using the import and export syntax. Modules can be exported using the export and export default keywords, and they can be imported using the import keyword.

Here’s a simple example to illustrate the creation and usage of modules in JavaScript:

In the file myModule.js:

File: myModule.js  
```javascript
export const myVariable = "Hello world";
export function myFunction() {
    console.log("This is my function");
}
export default class MyClass {
    constructor() {
    console.log("This is my class");
    }
}
```

We export the variable myVariable, the function myFunction(), and the JavaScript class MyClass in the module myModule.js.

In another JavaScript file (e.g., test.js), we import these previously exported elements:

## File: test.js

```javascript
import { myVariable, myFunction } from './myModule.js';
import MyClass from './myModule.js';

console.log(myVariable);
myFunction();
const myInstance = new MyClass();
```

You can also write the import statement on a single line as follows:

## File: test.js

```javascript
import MyClass, { myVariable, myFunction } from './myModule.js';
console.log(myVariable);
myFunction();
const myInstance = new MyClass();
```

This way, we have access to the exported elements from the myModule. js file in the test.js file.

## Step 1: Using Modules in HTML Files

To use JavaScript modules in an HTML file, we use the <script> tag with the type attribute set to "module".

Here’s an example of HTML code that imports a module named myModule.js:

File: index.html  
```html
<!DOCTYPE html>
<html>
<head>
    <title>Example of Using Modules in HTML</title>
</head>
<body>
    <h1>Example of Using Modules in HTML</h1>
<script type="module">
    import { myFunction } from './myModule.js';
    myFunction();
</script>
</body>
</html>
```

The message “This is my function” is displayed in the browser console, demonstrating that the myFunction() is successfully accessible in the JavaScript code of the HTML file.

## Step 2: Using the import Statement

The import statement is used in JavaScript to import modules from one JavaScript file to another. The basic syntax for importing a module is as follows:

## Importing data from a module

import { variableName, functionName } from './path/to/module';

This syntax allows you to import specific variables or functions from a module. The path to the module should be relative to the current JavaScript file.

Here are some examples of using the import statement in JavaScript:

Using import in a module  
```javascript
// Importing a specific variable
import { myVariable } from './myModule.js';
console.log(myVariable);
// Importing multiple variables and a function
import { myVar1, myVar2, myFunction } from './myModule.js';
console.log(myVar1);
console.log(myVar2);
myFunction();
// Importing all exported variables and functions
import * as myModule from './myModule.js';
console.log(myModule.myVar1);
console.log(myModule.myVar2);
myModule.myFunction();
```

In these examples, the import statement is used to import specific variables and functions from a module. In the last example, all exported variables and functions are imported using the \* operator, and an alias myModule is created to access the exported elements.

It’s important to note that the import statement can only be used in a module context. A JavaScript file must be explicitly marked as a module by using the type="module" directive in the <script> tag of the calling HTML file.

## Step 3: Using the export Statement

The export statement in JavaScript is used to export variables, functions, classes, or other elements from one JavaScript file to another. The exported elements can be used in other files by importing the module that contains them.

There are two main ways to export elements in JavaScript: using the export syntax or export default syntax.

The export syntax is used to export named elements. For example, to export a named variable myVariable and a named function myFunction from a file myModule.js, you can use the following syntax:

## Exporting variables (file myModule.js)

```typescript
export const myVariable = "Hello world";
export function myFunction() {
    console.log("This is my function");
}
```

The exported elements can then be imported into another file using the import statement. Here’s an example:

## Importing variables in another module

```javascript
import { myVariable, myFunction } from './myModule.js';
console.log(myVariable); // Displays "Hello world"
myFunction(); // Displays "This is my function"
```

## Step 4: Using the export default Statement

The export default syntax is used to export a default element from a module. For example, to export a default class from a file myModule.js, you can use the following syntax:

## Using export default (file myModule.js)

```javascript
export default class MyClass {
    constructor() {
    console.log("This is my class");
    }
}
```

In this example, the MyClass class is exported as the default. It can be imported into another file using the following syntax:

## Importing variables in another module

import MyClass from './myModule.js';

const myInstance = new MyClass(); // Creates a new instance of the MyClass class

In summary, the export statement in JavaScript allows you to export elements from a module to make them available in other JavaScript files. It can be used to export variables, functions, classes, or other elements and can be combined with the import statement to create modular and reusable JavaScript applications.

## Step 5: Difference Between export and export default Statements

The decision to use export or export default in JavaScript depends on how you want to expose module elements and import them later.

The export syntax is used to export multiple named elements from a module. This means that when a module is imported, the exported elements must be imported with their original names and enclosed in curly braces.

For example:

## Using export then import

```javascript
// In the file "myModule.js"
export const myVar1 = "Hello";
export const myVar2 = "World";
export function myFunction() {
```

```javascript
console.log("This is my function");
}
// In the file that imports the module
import { myVar1, myVar2, myFunction } from './myModule.js';
// with curly braces
```

In this example, the exported elements must be imported using their original names and enclosed in curly braces. If we try to import an element with a different name than the one specified in the export, an error will be generated.

The export default syntax is used to export a default element from a module. This means that the element exported as default can be imported later using a name of our choice. Only one element can be exported as default in a module, to avoid confusion.

JavaScript will understand that we want to import the default exported element in a module because we import it without using the curly braces notation, unlike elements exported using the export statement, which are imported with the curly braces notation.

For example:

Using export default then import  
```javascript
// In the file "myModule.js"
export default class MyClass {
    constructor() {
    console.log("This is my class");
    }
}

// In the file that imports the module
import MyCustomName from './myModule.js'; // without using curly braces
const myInstance = new MyCustomName();
```

In this example, the default exported element (the MyClass class) can be imported using a name of our choice (MyCustomName in this case). This can be useful if we want to give a more meaningful name to the imported element or avoid naming conflicts.

In summary, export is used to export multiple named elements from a module, while export default is used to export an element that will be considered the default one during import. The decision to use one or the other depends on how we want to expose module elements and how we want to import them into other files.

## Using Arrow Functions in JavaScript

Arrow functions are a new function syntax introduced in ECMAScript 6 (ES6) to write functions in a more concise and readable way. Here are the main differences between arrow functions and traditional functions:

More Concise Syntax: Arrow functions have a more concise syntax than traditional functions. Instead of the classic function() {function body}, arrow functions are written like this: () => {function body}.  
No Bound this Keyword: In traditional functions, the this keyword is bound to the object that calls the function. In arrow functions, this is bound to the lexical context in which the function is defined. This means that this in an arrow function refers to this in the parent scope (the value of this in an arrow function will be the same as that of the parent).

Apart from the concise writing aspect of arrow functions, the deciding factor to use them in JavaScript code is mostly the desired value for the this variable.

Let’s now look at the syntax of these functions and then explain the value of this in each use case.

## Step 1: Using Arrow Function Syntax

Let’s start by examining the writing syntax of these functions. Here’s an example:

Using traditional functions and arrow functions  
```javascript
// Traditional function to calculate the square of a number
function square(x) {
    return x * x;
}

// Arrow function to calculate the square of a number
const square2 = (x) => x * x;

// Using the function
console.log(square2(5)); // Result: 25
```

In this example, the first function is a traditional function that calculates the square of a number. The second function is the arrow version of the same function, which uses a more concise syntax. Both functions have the same functionality, but the arrow version is more concise and easier to read.

Note that the arrow function syntax includes parentheses around the parameters (in this case, x), followed by the arrow => and then the function body (in this case, x \* x). The arrow version doesn’t require the return keyword here because it automatically returns the calculated value.

Here’s an example of an arrow function in JavaScript that uses the return statement:

Functions using the return keyword  
```javascript
// Traditional function to find the largest number in an array
function findLargest(array) {
    let largest = 0;
    for (let i = 0; i < array.length; i++) {
```

Chapter 7 JavaSc ript Reminders  
```javascript
if (array[i] > largest) {
    largest = array[i];
}
return largest;
}

// Arrow function to find the largest number in an array
const findLargest2 = (array) => {
    let largest = 0;
    for (let i = 0; i < array.length; i++) {
    if (array[i] > largest) {
    largest = array[i];
    }
    }
    return largest;
}

// Using the function
console.log(findLargest2([4, 8, 2, 10, 5])); // Result: 10
```

In this example, the first function is a traditional function that finds the largest number in an array. The second function is the arrow version of the same function, which uses a more concise syntax. Both functions have the same functionality, and the arrow version also uses the return statement to return the calculated value.

Note that the arrow function syntax still includes parentheses around the parameters and the => arrow, but this time there are also curly braces to delimit the function body. The return statement is used to return the calculated value.

## Step 2: Understanding the Value of this in Arrow Functions

The value of this in an arrow function is determined by the lexical context in which the function is defined, unlike traditional functions where this is determined by how the function is called.

In an arrow function, this refers to the value of this in the parent scope. This means that if the arrow function is defined within an object, for example, this in the arrow function refers to the parent object, not the object that calls the function.

Here’s an example to illustrate this concept:

Values of this in traditional functions and arrow functions  
```javascript
const obj = {
    name: "John",
    sayHello: function() {
    console.log(`Hello, my name is ${this.name}'); // "John"
    (this refers to obj)
    },
    sayHelloArrow: () => {
    console.log(`Hello, my name is ${this.name}'); //
    undefined (this refers to the parent of obj)
    }
}

obj.sayHello(); // Result: "Hello, my name is John"
obj.sayHelloArrow(); // Result: "Hello, my name is undefined"
```

In this example, the object obj contains two functions: sayHello() and sayHelloArrow(). sayHello() is a regular function that uses this to access the name property of the object, while sayHelloArrow() is an arrow function that also uses this to access the name property.

When the sayHello() function is called, this refers to the obj object, allowing access to the name property and displaying it in the console. However, when the sayHelloArrow() function is called, this refers to the lexical context in which the function was defined, which is the global context in this case. Therefore, this.name is undefined in the arrow function, and undefined is displayed in the console.

Depending on the value of this that we want to access, we will use either a regular function or an arrow function.

## Using the map( ) and filter( ) Methods of the JavaScript Array Class

The map(callback) and filter(callback) methods are two commonly used high-level functions in JavaScript for manipulating arrays (or collections of objects). Here’s an explanation of each method:

## Step 1: Using the map( ) Method

The map(callback) method creates a new array by applying a given function, here named callback(), to each element of the original array. The map() method takes a callback() function as a parameter.

The callback(element, index, array) function is then applied to each element of the original array. This function can take up to three arguments:

1. element: The current element being processed  
2. index (optional): The index of the current element being processed in the array  
3. array (optional): The original array on which we are applying the function

The map() method then returns a new array with the results of applying the callback() function to each original element. The resulting array will have the same length as the original array.

Here’s a simple example for better understanding:

Using the map() method  
```javascript
const array = [1, 2, 3, 4, 5];
const doubledArray = array.map(function(element) {
    return element * 2;
});
console.log(doubledArray); // [2, 4, 6, 8, 10]
```

Here, we created an array with numbers, and then we used the map() method to create a new array with the same numbers, but multiplied by 2.

The map() method returns a new array constructed from the elements of the original array. The resulting array will have the same number of elements as the original array.

To reduce the number of elements in the resulting array, we will use the filter() method, which allows us to select the elements to be included in the resulting array (but without modifying them). Let’s now look at the filter() method.

## Step 2: Using the filter( ) Method

The filter(callback) method also creates a new array, but it filters the elements of the original array that satisfy a specified condition. This method also takes a callback() function as an argument, which will be applied to each element of the original array. This callback() function must return a boolean value: true if the element should be retained in the resulting array returned by the filter() method, false otherwise.

The callback(element, index, array) filter function also takes up to three arguments:

1. element: The current element being processed  
2. index (optional): The index of the current element being processed in the array  
3. array (optional): The original array on which the function is being applied

The filter() method then returns a new array with all the elements of the original array that satisfy the specified condition.

Here’s a simple example to better understand:

## Using the filter() method

```javascript
const array = [1, 2, 3, 4, 5];
const filteredArray = array.filter(function(element) {
    return element % 2 === 0; // Returns true if the element is even (element is kept), otherwise false
});
console.log(filteredArray); // [2, 4]
```

Here, we’ve created an array with numbers, and then we used the filter() method to create a new array with only the even numbers.

## Using Promise Objects in JavaScript

Promise objects in JavaScript are used for handling asynchronous tasks, which are tasks that don’t complete immediately. A Promise object represents a value that may not be available immediately but will be resolved (i.e., become available) at some point in the future.

## Step 1: Promise Object Definition

Promise objects are often created as return values from functions because they provide a clearer and more structured way of handling asynchronous tasks.

When an asynchronous task is executed, it doesn’t immediately return a result, as it needs to perform an operation that may take time (such as an HTTP request or file reading). While waiting for this operation to complete, the code that follows continues to execute, potentially causing synchronization and blocking issues.

Promise objects are used to address this issue. They provide a clear and structured way to handle asynchronous tasks by returning an object that represents the promise of a future result. This object can be used to attach callback functions that will be called once the asynchronous task is completed and the result is available.

For example, a function that performs an HTTP request can return a Promise object representing the promise of the request’s result. Callbacks can then be attached to this Promise object using the then() and catch() methods to handle successful results (with then()) or errors (with catch()) that may occur during the execution of the asynchronous task.

In summary, the Promise object is created as a return value from a function to handle asynchronous tasks in a structured manner by returning an object representing the promise of a future result and attaching callbacks to handle results or errors.

A Promise object can be in one of the following three states:

1. “pending”: The initial state of the Promise object, indicating that the asynchronous task is currently being executed  
2. “resolved”: The state in which the Promise object is resolved with a value  
3. “rejected”: The state in which the Promise object is rejected with an error reason

The Promise object exposes two methods for handling the results of the asynchronous task:

1. The then() Method: Used to handle the result if the task is successfully resolved  
2. The catch() Method: Used to handle errors that occur if the task is rejected

By using Promise objects, it’s possible to perform asynchronous tasks in JavaScript more efficiently and in a way that’s easier to read and maintain.

To understand the use of Promise objects, let’s take an example where we don’t use them and then the same example where we do.

## Step 2: Without Using Promise Objects

Here’s an example without using Promise objects.

Let’s say we want to load images from a server and display them in our application. Without Promise objects, we would have to use callbacks to handle the asynchrony:

## Without using Promise objects

```javascript
function loadImage(url, callback) {
    const img = new Image();
    img.onload = function() {
    // no error
    callback(null, img);
    };
    img.onerror = function() {
    // error
    callback("Unable to load the image.", null);
};
```

```javascript
img.src = url; // image loading
}
loadImage("https://example.com/image.jpg", function(error, img) {
    if (error) {
    console.error(error);
    } else {
    document.body.appendChild(img);
    }
});
```

This example uses the Image object to load an image from the server. The loadImage() function takes the image URL and a callback function as arguments. This callback will be invoked once the image has been loaded. After the image is loaded, further processing can take place within the callback function, allowing for handling of the asynchrony. The callback function has two arguments: a possible error and the loaded img (image) itself.

## Step 3: Using Promise Objects

Now, here’s the same example using Promise objects:

## Using Promise objects

```javascript
function loadImage(url) {
    return new Promise(function(resolve, reject) {
    const img = new Image();
    img.onload = function() {
    // no error
    resolve(img);
    };
};
```

Chapter 7 JavaSc ript Reminders  
```javascript
img.onerror = function() {
    // error
    reject("Unable to load the image.");
};
img.src = url; // image loading
});
}

loadImage("https://example.com/image.jpg")
.then(function(img) {
document.body.appendChild(img);
})
.catch(function(error) {
console.error(error);
});
```

Here, the loadImage() function returns a Promise object that is resolved with the image if the image loading succeeds, or is rejected with an error message if it fails. By using the then() method, we can handle the image once it has been loaded, and with the catch() method, we can handle errors that occur.

The use of Promise objects in this example makes the code more readable and easier to understand and provides simplified error handling.

## Using async and await Statements in JavaScript

The async and await statements are features of JavaScript that make working with Promise objects even more readable and understandable for handling asynchronous tasks.

By using async and await statements, code can be written synchronously (i.e., with sequentially following instructions) while still effectively managing asynchronous tasks. The async statement is used to mark a function as asynchronous, allowing the use of the await statement within that function.

The await statement is used to wait for the resolution of a Promise object before continuing the code execution. This avoids the use of callbacks and results in code that is easier to read and understand.

For example, here’s a usage example of Promise objects to make an HTTP request. We will then see how to write the same code using async and await statements.

## Using Promise objects to make an HTTP request

```javascript
fetch("https://api.example.com/data")
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error(error));
```

The fetch() and json() methods in JavaScript each return a Promise object, enabling the use of the then() and catch() methods on these methods.

Now, here’s how we can rewrite this code using async and await statements:

## Using async and await statements to make an HTTP request

```javascript
async function getData() {
    try {
    const response = await fetch("https://api.example.com/data");
    const data = await response.json();
    console.log(data);
    } catch (error) {
```

Chapter 7 JavaSc ript Reminders  
```javascript
console.error(error);
}
}
getData();
```

Here, the getData() function is marked as async, which allows (within the getData() function) the use of the await statement to wait for the resolution of Promise objects returned by the fetch() function and the json() method. The use of async and await statements enables writing code that is more readable and easier to understand while efficiently managing asynchronous tasks.

In summary, the use of async and await statements provides an easier and more readable way to utilize Promise objects for handling asynchronous tasks. This helps avoid the use of callbacks and reduces code complexity.

## Creating an Asynchronous Function That Utilizes JavaScript’s await Statement

Let’s now see how to create an asynchronous function that can use the await statement. For this purpose, the function using await should fall into one of the following two cases:

1. The function returns a Promise object. This is the case, for example, with the previous fetch() and json() methods.  
2. The function is declared with the async keyword. In this case, the function’s return is always considered as a Promise object (even if the function returns another value).

Let’s examine these two cases now.

# Step 1: Using await with a Function That Returns a Promise Object

For await to be used with a function, the function can return a Promise object or be declared with the async keyword.

Here’s an example of a function that returns a Promise object:

## Function returning a Promise object

```javascript
function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
```

The wait(ms) function takes a number of milliseconds as input and returns a Promise object that will resolve after the specified number of milliseconds. The function utilizes the setTimeout() function to trigger the resolution of the Promise object after a specified delay.

To use the wait(ms) function with the await statement, you simply need to call it within a function marked with async, like this:

## Usage of await in an async function

```javascript
async function myFunction() {
    console.log("Start"); // Display "Start"
    await wait(2000); // Wait for 2 seconds
    console.log("End"); // Then display "End" (after 2 seconds)
}
myFunction();
```

This myFunction() function uses the await statement to wait for the resolution of the Promise object returned by the wait() function. The function prints “Start” to the console, waits for two seconds using await wait(2000), and then prints “End” to the console.

In cases where the wait(ms) function wants to return a value, you can simply provide that value (“value”) as a parameter in the resolve(value) function call.

The wait(ms) function becomes the following:

Function wait(ms) that returns a value  
```javascript
function wait(ms) {
    return new Promise(resolve => setTimeout(() =>
    resolve("Waiting for " + ms + " ms"), ms));
}
```

We can no longer simply indicate setTimeout(resolve, ms) as before, because now we need to explicitly call the resolve() function and pass the return value as a parameter. Hence, the new syntax is written as setTimeout(() => resolve(value), ms).

We use the value returned by the wait(ms) function as follows:

Using the value returned by the wait(ms) function  
```javascript
async function myFunction() {
    console.log("Start"); // Display "Start"
    const result = await wait(2000); // Wait for 2 seconds
    console.log(result); // Display the result returned by the wait() function
    console.log("End"); // Then display "End"
}
myFunction();
```

## Step 2: Using await with a Function Declared with async

This is the second way to use the await statement when calling a function. The function must have been declared using the async keyword during its definition.

A function declared with the async keyword is considered to return a Promise object. Therefore, it can be used when called with the then() and catch() methods or used with the await keyword.

Using the myFunction() function with “await”  
```javascript
function wait(ms) {
    return new Promise(resolve => setTimeout(() =>
    resolve("Waiting for " + ms + " ms"), ms));
}

async function myFunction() {
    console.log("Start"); // Display "Start"
    const result = await wait(2000); // Wait for 2 seconds
    console.log(result); // Display the result returned by the wait() function
    console.log("End"); // Then display "End"
    return "myFunction(): Waiting for 2000ms";
}

async function myMainFunction() {
    const result = await myFunction();
    console.log("result =", result);
}

myMainFunction();
```

Since the myFunction() is declared with async, it can be used within a new function called myMainFunction() using the await keyword. The result returned by myFunction() will be used as the return value in myMainFunction(), asynchronously (after waiting for two seconds).

The same process can be written using promises and the then() and catch() methods:

Using promises instead of await  
```typescript
function wait(ms) {
    console.log("wait(" + ms + ")");
    return new Promise(resolve => setTimeout(() =>
    resolve("Waiting for " + ms + " ms"), ms));
}

async function myFunction() {
    console.log("Start"); // Display "Start"
    const result = await wait(2000); // Wait for 2 seconds
    console.log(result); // Display the result returned by the wait() function
    console.log("End"); // Then display "End"
    return "myFunction(): Waiting for 2000ms";
}

myFunction().then((res) => { console.log(res) });
```

The then(res) method used on the promise myFunction() allows retrieving the result of the promise, which is the string “myFunction(): Waiting for 2000ms”, in the parameter res.

## Conclusion

In this chapter, we have covered the fundamentals of JavaScript, which are the ones used in programs written with Vue.js. This knowledge is necessary to harness the full power of Vue.js in our applications.