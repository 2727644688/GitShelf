document root Hello World, Accessing the Document Root (Windows)

document root viewed, Testing the Installation

Microsoft Visual C++ Redistributable, Installing AMPPS on Windows

PHP version, Installing AMPPS on Windows

serving pages from document root versus filesystem, Accessing the Document Root (Windows)

testing the installation, Testing the Installation-Testing the Installation

MySQL

command line interface startup, Windows users

table names case-insensitive, MySQL Commands

WAMPServer, Alternative WAMPs

web browsers

<pre> and </pre> tags, Declaring a Class, Multidimensional Arrays

autofocus, The autofocus attribute

console

JavaScript errors displayed, Debugging JavaScript Errors

opening, Debugging JavaScript Errors

Safari Develop menu enabled, Debugging JavaScript Errors cookies

disabled, Using Cookies in PHP, Using Sessions

editing, Using Cookies in PHP

reading, Accessing a Cookie

request/response process, Using Cookies in PHP

## CSS

Can I Use... website, Advanced CSS, Using the auto Value

development, Advanced CSS

flexbox editor, Flexbox

font specification, Web Fonts

grid editor, Grid Container

support of, Advanced CSS

events normalized by React, Events in React

Fetch API, The Fetch API

(see also Fetch API (JavaScript))

htmlspecialchars protection, System Calls, Fetching a Result,

Displaying the Form, HTTP Authentication

JavaScript running within, Exploring JavaScript

errors displayed in browser console, Debugging JavaScript Errors

history object, Using the DOM

JavaScript engine required, JavaScript and HTML Text

running outside of browser via Node.js, Introduction to Node.js

multiline string output, Using a nowdoc

request/response process, The Request/Response Procedure-The

Request/Response Procedure

cookies, Using Cookies in PHP

Safari browser Develop menu enabled, Debugging JavaScript Errors

testing development work, Setting Up a Development Server

uploading via multipart/form-data encoding, Uploading Files

user-agent string, Preventing session hijacking

web design (see dynamic web design)

web fonts (CSS), Web Fonts

Google web fonts, Google Web Fonts

privacy information online, Google Web Fonts

website, Google Web Fonts

specifying for browser, Web Fonts

Web Hypertext Application Technology Working Group (WHATWG), And Then There’s HTML5

web page for book, How to Contact Us

web servers

Apache, The Apache Web Server

(see also Apache web server; Node.js)

dynamic output via PHP, Using PHP, Introduction to PHP

(see also PHP)

file\_get\_contents function in PHP, Reading an Entire File

HTTP authentication, HTTP Authentication-An Example Program

example program, An Example Program-An Example Program

hash storage documentation online, Using password\_hash

htmlspecialchars function, HTTP Authentication

installed on server, HTTP Authentication

size of storage for hashes, Using password\_hash

storing usernames and passwords, Storing Usernames and

Passwords-Using password\_verify

validating username and password, HTTP Authentication

verifying password against hash, Using password\_verify,

login.php

Node.js alternative to Apache, Node.js: An Alternative to Apache

building a Node.js web server, Building a Functioning Web

Server-Building a Functioning Web Server

building an Apache web server (see development server setup)

port number, String variables

request/response process, The Request/Response Procedure-The

Request/Response Procedure

cookies, Using Cookies in PHP

security via, Using JavaScript

serving pages from document root versus filesystem, Accessing the

Document Root (Windows), Installing AMPPS on macOS

sessions, Using Sessions-Using a shared server

about, Using Sessions

ending a session, Ending a Session

security, Session Security-Using a shared server

setting a timeout, Setting a Timeout starting a session, Starting a Session-Starting a Session uploading a file, Uploading Files-Validation working remotely, Working Remotely logging in, Logging In transferring files, Transferring Files

WHATWG (Web Hypertext Application Technology Working Group), And Then There’s HTML5

WHERE keyword (MySQL), WHERE

deleting a row, DELETE

LIKE keyword, WHERE

% before or after text, WHERE

logical operators, Using Logical Operators

while loops

JavaScript, while Loops

PHP, while Loops-while Loops

width attribute in forms (HTML), The width and height attributes

wildcard (.) in regular expressions, Wildcard Matching

window object (JavaScript)

centering in-browser alerts or dialogs, Other Properties

properties, Other Properties

documentation online, Other Properties

Windows installation of Node.js, Installing Node.js on Windows-Installing Node.js on Windows

Windows PowerShell

MySQL command line, Windows users

MySQL errors, Creating a Backup File

Windows Subsystem for Linux (WSL) and Node.js, Installing Node.js on Windows

Windows, Apache, MySQL, PHP (WAMP), What Is a WAMP, MAMP, or LAMP?

installing AMPPS on Windows, Installing AMPPS on Windows-Installing AMPPS on Windows

alternative WAMPs, Alternative WAMPs

AMPPS documentation, Installing AMPPS on Windows, Alternative WAMPs

configuration, Testing the Installation

document root described, Accessing the Document Root (Windows)

document root Hello World, Accessing the Document Root (Windows)

document root viewed, Testing the Installation

Microsoft Visual C++ Redistributable, Installing AMPPS on Windows

PHP version, Installing AMPPS on Windows

serving pages from document root versus filesystem, Accessing the Document Root (Windows)

testing the installation, Testing the Installation-Testing the Installation

MySQL

command line interface startup, Windows users

table names case-insensitive, MySQL Commands

WinSCP for SFTP, Transferring Files

word character (\w) in regular expressions, Summary of Metacharacters

nonword character (\W), Summary of Metacharacters

word-wrap property (CSS), The word-wrap Property

working remotely

about, Working Remotely

code editors, Using a Code Editor

logging in, Logging In

MySQL command line interface startup, MySQL on a remote server

transferring files, Transferring Files

World Wide Web

history, Introduction to Dynamic Web Content

Web 1.0, Introduction to Dynamic Web Content

Web 1.1, The Benefits of PHP, MySQL, JavaScript, CSS, and HTML

Web 2.0, And Then There’s HTML5

writing to files (PHP)

file pointer, Updating Files

fwrite function, Creating a File

locking files for multiple accesses, Locking Files for Multiple Accesses

updating a file, Updating Files

WSL (Windows Subsystem for Linux) and Node.js, Installing Node.js on Windows

## X

XAMPP, Alternative WAMPs

XHR (XMLHttpRequest) object (JavaScript), Using XMLHttpRequest documentation online, Using XMLHttpRequest

XML in JavaScript via Babel JSX extension, Accessing the React Files

XMLHttpRequest (XHR) object (JavaScript), Using XMLHttpRequest documentation online, Using XMLHttpRequest

xor (exclusive or) logical operator (PHP), Logical operators, Operator precedence, Logical operators-Logical operators

XSS (cross-site scripting) attack, Fetching a Result, Preventing JavaScript Injection into HTML

article by OWASP online, Sanitizing Input

innerHTML property risks, Your First Asynchronous Program

sanitizing input, Sanitizing Input

## Y

Y2K38 bug, Date and Time Functions

YEAR data type (MySQL), Data Types, DATE and TIME types

CHAR(4) instead, Data Types

## About the Author

Robin Nixon is a broadcaster and author who has over 40 years of experience with writing software, developing websites and apps, and managing teams of developers. He also has an extensive history of writing about computers and technology, with a portfolio of over 500 published magazine articles and over 40 books, many of which have been translated into other languages.

Robin started his computing career in the Cheshire homes for disabled people, where he was responsible for setting up computer rooms in a number of residential homes, and for evaluating and tailoring hardware and software so that disabled people could use the new technology, sometimes by means of only a single switch operated by mouth or finger. Robin’s first computer was a Tandy TRS 80 Model 1 with a massive 4KB of RAM!

Robin eventually went on to work for some of the UK’s top-selling IT magazine publishers, where he held several roles including editorial, promotions, and cover disc editing.

With the dawn of the internet in the 1990s, Robin helped spearhead many new web developments such as the first internet radio station, one of the first webmail services, the first fully interactive chat service (before the development of Ajax), and the first widespread use of pop-up window technology.

## Colophon

The animals on the cover of Learning PHP, MySQL & JavaScript are sugar gliders (Petaurus breviceps). Sugar gliders are small, gray-furred creatures that grow to an adult length of 6 to 7.5 inches. Their tails, distinguished by a black tip, are usually as long as their bodies. Membranes extend between their wrists and ankles and provide an aerodynamic surface that helps them glide between trees.

Sugar gliders are native to Australia and Tasmania. They prefer to live in the hollow parts of eucalyptus and other large trees with several other adult sugar gliders and their own children.

Though sugar gliders reside in groups and defend their territory together, they don’t always live in harmony. One male will assert his dominance by marking the group’s territory with his saliva and marking group members with a distinctive scent produced from his forehead and chest glands. This ensures that members of the group know when an outsider approaches.

Sugar gliders make popular pets because they are inquisitive and playful, and because many think they are cute. However, because they are exotic animals, sugar gliders need specialized, complicated diets; healthy housing requires a cage or space no less than the size of an aviary; it’s not uncommon for them to lose control of their bowels while playing or eating; and in some states and countries, it is illegal to own sugar gliders as household pets.

Many of the animals on O’Reilly covers are endangered; all of them are important to the world.

The cover illustration is by Karen Montgomery, based on a black-and-white engraving from Johnson’s Natural History. The series design is by Edie Freedman, Ellie Volckhausen, and Karen Montgomery. The cover fonts are Gilroy Semibold and Guardian Sans. The text font is Adobe Minion Pro; the heading font is Adobe Myriad Condensed; and the code font is Dalton Maag’s Ubuntu Mono.